/* 用蒙特卡洛算出 169 手牌的单挑胜率, 生成 src/ranking.js */
globalThis.GTO = {};
require('../src/evaluator.js');
require('../src/ranges.js');
require('../src/equity.js');
const fs = require('fs');
const path = require('path');
const { ranges: RG, equity: EQ } = globalThis.GTO;

const ITERS = 60000;
const rows = [];
for (const key of RG.ALL_HANDS) {
  const [c1, c2] = RG.keyToCombos(key)[0];
  const opp = EQ.fullRangeCombos([c1, c2]);
  const e = EQ.equity([c1, c2], [], [opp], ITERS).equity;
  rows.push([key, e]);
}
rows.sort((a, b) => b[1] - a[1]);

const order = rows.map((r) => r[0]);
const eqMap = {};
rows.forEach((r) => { eqMap[r[0]] = Math.round(r[1] * 1000) / 1000; });

const out = `/* 自动生成 (tools/gen-ranking.js) — 169 手牌按单挑胜率排序 */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});
  const ORDER = ${JSON.stringify(order)};
  const HU_EQUITY = ${JSON.stringify(eqMap)};
  const RANK_INDEX = {};
  ORDER.forEach(function (k, i) { RANK_INDEX[k] = i; });
  // 按组合数加权的累计百分位: 0 = 最强 (AA), 1 = 最弱
  const PERCENTILE = {};
  (function () {
    let acc = 0;
    ORDER.forEach(function (k) {
      const n = k.length === 2 ? 6 : k[2] === 's' ? 4 : 12;
      PERCENTILE[k] = (acc + n / 2) / 1326;
      acc += n;
    });
  })();
  G.ranking = { ORDER: ORDER, RANK_INDEX: RANK_INDEX, HU_EQUITY: HU_EQUITY, PERCENTILE: PERCENTILE };
})(typeof globalThis !== 'undefined' ? globalThis : this);
`;
fs.writeFileSync(path.join(__dirname, '../src/ranking.js'), out);
console.log('已写入 src/ranking.js');
console.log('最强 12 手:', order.slice(0, 12).join(' '));
console.log('最弱 8 手:', order.slice(-8).join(' '));
console.log('AA=' + eqMap.AA, ' 72o=' + eqMap['72o'], ' AKs=' + eqMap.AKs, ' 22=' + eqMap['22']);
