globalThis.GTO = {};
['evaluator','ranges','ranking','equity','advisor'].forEach(m=>require('../src/'+m+'.js'));
const { cards: C, ranges: RG, equity: EQ, advisor: AD } = globalThis.GTO;
const h=s=>s.trim().split(/\s+/).map(C.cardFromStr);
const ctx={tableSize:6,heroPos:'BTN',hero:h('As Ks'),board:h('Qs 7s 2h'),street:'flop',
 effStack:96,potBB:6,toCallBB:4,scenario:'unopened',raiserPos:'CO',openSizeBB:2.5,callers:0,
 limpers:0,villains:1,villainRole:'bbdefend',villainPos:'BB',history:{},facing:'bet',
 inPosition:true,heroInvested:0};
// 预热(建缓存)
AD.analyze(ctx);
let t=Date.now(); for(let i=0;i<5;i++) AD.analyze(ctx);
console.log('analyze 全流程: '+((Date.now()-t)/5).toFixed(0)+'ms/次');

const base=RG.flatRange('BTN','BB');
const combos=EQ.rangeToCombos(base, ctx.hero.concat(ctx.board));
console.log('对手组合数: '+combos.length);
t=Date.now(); for(let i=0;i<20;i++) EQ.narrowRange(combos, ctx.board,'bet',0.66);
console.log('narrowRange: '+((Date.now()-t)/20).toFixed(1)+'ms');
const nr=EQ.narrowRange(combos, ctx.board,'bet',0.66);
t=Date.now(); for(let i=0;i<20;i++) EQ.equity(ctx.hero, ctx.board,[nr],24000);
console.log('equity 24k: '+((Date.now()-t)/20).toFixed(1)+'ms');
t=Date.now(); for(let i=0;i<20;i++) AD.takeTopOnBoard(nr, ctx.board, 0.6);
console.log('takeTopOnBoard: '+((Date.now()-t)/20).toFixed(1)+'ms');
t=Date.now(); for(let i=0;i<20;i++) AD.rangeFromCombos(nr);
console.log('rangeFromCombos: '+((Date.now()-t)/20).toFixed(1)+'ms');
t=Date.now(); for(let i=0;i<2000;i++) EQ.features([ctx.hero[0],ctx.hero[1]], ctx.board);
console.log('features x2000: '+(Date.now()-t)+'ms');
t=Date.now(); for(let i=0;i<2000;i++) EQ.percentileOnBoard([ctx.hero[0],ctx.hero[1]], ctx.board);
console.log('percentile x2000: '+(Date.now()-t)+'ms');
