/* ============================================================
   evaluator.js — 牌型评估内核
   牌用 0..51 的整数表示: card = rank * 4 + suit
   rank: 0=2 … 12=A     suit: 0=♠ 1=♥ 2=♦ 3=♣
   ============================================================ */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});

  const RANK_CHARS = '23456789TJQKA';
  const SUIT_CHARS = 'shdc';
  const SUIT_SYMBOLS = ['♠', '♥', '♦', '♣'];
  const RANK_NAMES_CN = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

  const CAT_NAMES = [
    '高牌', '一对', '两对', '三条', '顺子', '同花', '葫芦', '四条', '同花顺',
  ];

  function makeCard(rank, suit) { return rank * 4 + suit; }
  function cardRank(c) { return c >> 2; }
  function cardSuit(c) { return c & 3; }

  function cardToStr(c) { return RANK_CHARS[c >> 2] + SUIT_CHARS[c & 3]; }
  function cardToDisplay(c) { return RANK_NAMES_CN[c >> 2] + SUIT_SYMBOLS[c & 3]; }

  function cardFromStr(s) {
    const r = RANK_CHARS.indexOf(s[0].toUpperCase());
    const u = SUIT_CHARS.indexOf(s[1].toLowerCase());
    if (r < 0 || u < 0) return -1;
    return makeCard(r, u);
  }

  /* ---- 顺子查表: 13 位 rank 掩码 → 顺子最大牌 rank, 无顺子为 -1 ---- */
  const STRAIGHT = new Int8Array(1 << 13).fill(-1);
  for (let m = 0; m < 1 << 13; m++) {
    let best = -1;
    for (let hi = 12; hi >= 4 && best < 0; hi--) {
      let ok = true;
      for (let k = 0; k < 5; k++) if (!(m & (1 << (hi - k)))) { ok = false; break; }
      if (ok) best = hi;
    }
    // A2345 (轮子), A 当 1 用, 记为 5 高顺子 → rank 3
    if (best < 0 && (m & (1 << 12)) && (m & 1) && (m & 2) && (m & 4) && (m & 8)) best = 3;
    STRAIGHT[m] = best;
  }

  /* ---- 打分: cat<<20 | k1<<16 | … | k5, 数值越大越强 ---- */
  function mk(cat, k1, k2, k3, k4, k5) {
    return (cat << 20) | (k1 << 16) | (k2 << 12) | (k3 << 8) | (k4 << 4) | k5;
  }
  function scoreCategory(score) { return score >>> 20; }

  function topN(mask, n) {
    const out = [0, 0, 0, 0, 0];
    let i = 0;
    for (let r = 12; r >= 0 && i < n; r--) if (mask & (1 << r)) out[i++] = r;
    return out;
  }

  // 复用的临时数组, 避免蒙特卡洛里反复分配
  const _rc = new Int8Array(13);
  const _sc = new Int8Array(4);
  const _sm = new Int32Array(4);

  /**
   * 评估 5~7 张牌, 返回可直接比大小的整数分值。
   */
  function evaluate(cards) {
    _rc.fill(0); _sc.fill(0); _sm.fill(0);
    let mask = 0;
    for (let i = 0; i < cards.length; i++) {
      const c = cards[i], r = c >> 2, s = c & 3;
      _rc[r]++; _sc[s]++; _sm[s] |= 1 << r; mask |= 1 << r;
    }

    let flushSuit = -1;
    for (let s = 0; s < 4; s++) if (_sc[s] >= 5) { flushSuit = s; break; }

    if (flushSuit >= 0) {
      const sfTop = STRAIGHT[_sm[flushSuit]];
      if (sfTop >= 0) return mk(8, sfTop, 0, 0, 0, 0);
    }

    let quad = -1;
    const trips = [], pairs = [];
    for (let r = 12; r >= 0; r--) {
      const n = _rc[r];
      if (n === 4) { if (quad < 0) quad = r; }
      else if (n === 3) trips.push(r);
      else if (n === 2) pairs.push(r);
    }

    if (quad >= 0) {
      const k = topN(mask & ~(1 << quad), 1);
      return mk(7, quad, k[0], 0, 0, 0);
    }
    if (trips.length >= 2) return mk(6, trips[0], trips[1], 0, 0, 0);
    if (trips.length === 1 && pairs.length >= 1) return mk(6, trips[0], pairs[0], 0, 0, 0);
    if (flushSuit >= 0) {
      const t = topN(_sm[flushSuit], 5);
      return mk(5, t[0], t[1], t[2], t[3], t[4]);
    }
    const st = STRAIGHT[mask];
    if (st >= 0) return mk(4, st, 0, 0, 0, 0);
    if (trips.length === 1) {
      const k = topN(mask & ~(1 << trips[0]), 2);
      return mk(3, trips[0], k[0], k[1], 0, 0);
    }
    if (pairs.length >= 2) {
      const k = topN(mask & ~(1 << pairs[0]) & ~(1 << pairs[1]), 1);
      return mk(2, pairs[0], pairs[1], k[0], 0, 0);
    }
    if (pairs.length === 1) {
      const k = topN(mask & ~(1 << pairs[0]), 3);
      return mk(1, pairs[0], k[0], k[1], k[2], 0);
    }
    const k = topN(mask, 5);
    return mk(0, k[0], k[1], k[2], k[3], k[4]);
  }

  /** 牌型的中文描述, 例如 “两对 A、7” */
  function describeScore(score) {
    const cat = score >>> 20;
    const k1 = (score >> 16) & 15, k2 = (score >> 12) & 15;
    const R = RANK_NAMES_CN;
    switch (cat) {
      case 8: return k1 === 12 ? '皇家同花顺' : R[k1] + ' 高同花顺';
      case 7: return R[k1] + ' 四条';
      case 6: return R[k1] + ' 满 ' + R[k2] + ' 葫芦';
      case 5: return R[k1] + ' 高同花';
      case 4: return R[k1] + ' 高顺子';
      case 3: return R[k1] + ' 三条';
      case 2: return '两对 ' + R[k1] + '·' + R[k2];
      case 1: return R[k1] + ' 一对';
      default: return R[k1] + ' 高牌';
    }
  }

  G.cards = {
    RANK_CHARS, SUIT_CHARS, SUIT_SYMBOLS, RANK_NAMES_CN, CAT_NAMES,
    makeCard, cardRank, cardSuit, cardToStr, cardToDisplay, cardFromStr,
    evaluate, describeScore, scoreCategory, STRAIGHT,
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
