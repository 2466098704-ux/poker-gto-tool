/* 算法自检 */
globalThis.GTO = {};
require('../src/evaluator.js');
require('../src/ranges.js');
require('../src/equity.js');
const { cards: C, ranges: RG, equity: EQ } = globalThis.GTO;

let fails = 0;
function check(name, cond, extra) {
  if (!cond) { fails++; console.log('  FAIL  ' + name + (extra ? '  → ' + extra : '')); }
  else console.log('  ok    ' + name + (extra ? '  (' + extra + ')' : ''));
}
function h(s) { return s.trim().split(/\s+/).map(C.cardFromStr); }

console.log('\n— 牌型评估 —');
const sf = C.evaluate(h('As Ks Qs Js Ts 2h 3d'));
check('皇家同花顺', C.describeScore(sf) === '皇家同花顺', C.describeScore(sf));
check('四条 > 葫芦', C.evaluate(h('7s 7h 7d 7c 2s 3h 4d')) > C.evaluate(h('As Ah Ad Ks Kh 2d 3c')));
check('葫芦 > 同花', C.evaluate(h('2s 2h 2d 3s 3h 9c Tc')) > C.evaluate(h('As Js 9s 5s 3s 2h 4d')));
check('同花 > 顺子', C.evaluate(h('As Js 9s 5s 3s 2h 4d')) > C.evaluate(h('9s 8h 7d 6c 5s 2h 3d')));
check('轮子顺 A2345', C.describeScore(C.evaluate(h('As 2h 3d 4c 5s Kh Qd'))) === '5 高顺子', C.describeScore(C.evaluate(h('As 2h 3d 4c 5s Kh Qd'))));
check('两对取最高两对', C.describeScore(C.evaluate(h('As Ah Ks Kh 2d 2c 5s'))) === '两对 A·K', C.describeScore(C.evaluate(h('As Ah Ks Kh 2d 2c 5s'))));
check('三条', C.describeScore(C.evaluate(h('9s 9h 9d As Kh 2c 3d'))) === '9 三条');
check('同花顺 > 四条', C.evaluate(h('9s 8s 7s 6s 5s 2h 2d')) > C.evaluate(h('As Ah Ad Ac 5s 2h 3d')));
check('踢脚牌生效', C.evaluate(h('As Ah Ks 9d 5c 3h 2s')) > C.evaluate(h('As Ah Qs 9d 5c 3h 2s')));

console.log('\n— 范围解析 —');
const r1 = RG.parseRange('22+');
check('22+ 共 13 个对子', Object.keys(r1).length === 13);
check('22+ 占 5.88%', Math.abs(RG.rangePercent(r1) - 5.88) < 0.05, RG.rangePercent(r1).toFixed(2) + '%');
const r2 = RG.parseRange('A2s+');
check('A2s+ 共 12 手', Object.keys(r2).length === 12);
const r3 = RG.parseRange('AKs:0.5');
check('权重解析', r3.AKs === 0.5);
const r4 = RG.parseRange('A5s-A2s');
check('区间解析', Object.keys(r4).sort().join(',') === 'A2s,A3s,A4s,A5s', Object.keys(r4).join(','));
check('handKey AKs', RG.handKey(C.cardFromStr('As'), C.cardFromStr('Ks')) === 'AKs');
check('handKey AKo', RG.handKey(C.cardFromStr('Ah'), C.cardFromStr('Ks')) === 'AKo');
check('169 手牌', RG.ALL_HANDS.length === 169, RG.ALL_HANDS.length);

console.log('\n— 开池范围百分比 —');
for (const [name, str] of Object.entries(RG.CHARTS.RFI)) {
  console.log('  ' + name.padEnd(6) + RG.rangePercent(RG.parseRange(str)).toFixed(1) + '%');
}

console.log('\n— 胜率 (蒙特卡洛 30k) —');
function eqVs(heroStr, oppStr, boardStr) {
  const hero = h(heroStr);
  const board = boardStr ? h(boardStr) : [];
  const opp = EQ.rangeToCombos(RG.parseRange(oppStr), hero.concat(board));
  return EQ.equity(hero, board, [opp], 30000).equity;
}
const t0 = Date.now();
const aaVskk = eqVs('As Ah', 'KK');
check('AA vs KK ≈ 82%', Math.abs(aaVskk - 0.82) < 0.02, (aaVskk * 100).toFixed(1) + '%');
const akVsqq = eqVs('As Ks', 'QQ');
check('AKs vs QQ ≈ 46%', Math.abs(akVsqq - 0.46) < 0.02, (akVsqq * 100).toFixed(1) + '%');
const akoVsqq = eqVs('As Kh', 'QQ');
check('AKo vs QQ ≈ 43%', Math.abs(akoVsqq - 0.43) < 0.02, (akoVsqq * 100).toFixed(1) + '%');
const t76 = eqVs('7s 6s', 'AA');
check('76s vs AA ≈ 23%', Math.abs(t76 - 0.23) < 0.02, (t76 * 100).toFixed(1) + '%');
const fd = eqVs('As Ks', 'QQ', 'Qs 7s 2h');
check('裸同花听牌 vs 顶set', fd > 0.15 && fd < 0.30, (fd * 100).toFixed(1) + '%');
console.log('  用时 ' + (Date.now() - t0) + 'ms / 5 次 30k 模拟');

console.log('\n— 河牌精确枚举 —');
const heroR = h('As Ks'), boardR = h('Qs Js Ts 2h 3d');
const exact = EQ.equityExact(heroR, boardR, EQ.rangeToCombos(RG.parseRange('22+, A2s+, K2s+'), heroR.concat(boardR)));
check('皇家同花顺应接近 100%', exact.equity > 0.99, (exact.equity * 100).toFixed(1) + '%');

console.log('\n— 牌力特征 —');
const f1 = EQ.features(h('As Ks'), h('Ah 7d 2c'));
check('顶对识别', f1.pairLabel === '顶对', f1.pairLabel);
const f2 = EQ.features(h('9s 8s'), h('7s 6h 2c'));
check('两头顺听牌', f2.oesd === true);
const f3 = EQ.features(h('As Ks'), h('Qs 7s 2h'));
check('同花听牌', f3.flushDraw === true && f3.outs >= 9, 'outs=' + f3.outs);
const f4 = EQ.features(h('Qs Qh'), h('7s 6h 2c'));
check('超对', f4.pairLabel === '超对', f4.pairLabel);
const pct = EQ.percentileOnBoard(h('As Ah'), h('Ad 7d 2c'));
check('三条 A 百分位 > 0.95', pct > 0.95, pct.toFixed(3));

console.log('\n— 范围收窄 —');
const board = h('As 7d 2c');
const wide = EQ.rangeToCombos(RG.parseRange('22+, A2s+, K9s+, QTs+, JTs, ATo+, KQo'), board);
const afterBet = EQ.narrowRange(wide, board, 'bet', 0.66);
const w0 = EQ.combosWeight(wide), w1 = EQ.combosWeight(afterBet);
check('下注后范围变窄', w1 < w0 * 0.75, (w1 / w0 * 100).toFixed(0) + '% 保留');
const afterCheck = EQ.narrowRange(wide, board, 'check');
check('过牌后范围基本保留', EQ.combosWeight(afterCheck) > w0 * 0.85);

console.log('\n' + (fails ? '❌ ' + fails + ' 项失败' : '✅ 全部通过'));
process.exit(fails ? 1 : 0);
