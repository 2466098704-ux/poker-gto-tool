/* ============================================================
   ui.js — 界面与交互
   布局思路: 答案常驻底部, 输入压成可点的短语, 配置收进抽屉
   ============================================================ */
(function (root) {
  'use strict';
  const G = root.GTO;
  const C = G.cards, RG = G.ranges, AD = G.advisor;

  const $ = (id) => document.getElementById(id);
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function btn(cls, text) {
    const b = el('button', cls, text);
    b.type = 'button';
    return b;
  }

  const ACT_LABEL = { fold: '弃牌', call: '跟注', raise: '加注', bet: '下注', check: '过牌' };

  /* ============ 状态 ============ */
  const DEFAULT = {
    tableSize: 6,
    heroPos: 'BTN',
    hero: [null, null],
    board: [null, null, null, null, null],
    effStack: 100,
    scenario: 'unopened',
    raiserPos: 'CO',
    openSizeBB: 2.5,
    threeBetBB: 8,
    fourBetBB: 20,
    callers: 0,
    limpers: 1,
    villains: 1,
    villainPos: 'BB',
    villainRole: 'bbdefend',
    seatTarget: 'hero',
    facing: 'none',
    potBB: 1.5,
    toCallBB: 0,
    potTouched: false,
    lastStreetN: 0,
    history: { flop: 'none', turn: 'none', river: 'none' },
  };
  let S = load();
  let openChip = null;
  let tab = 'nums';
  let lastResult = null;

  function load() {
    try {
      const raw = localStorage.getItem('gto-holdem-v1');
      if (raw) return Object.assign(JSON.parse(JSON.stringify(DEFAULT)), JSON.parse(raw));
    } catch (e) { /* 缓存坏了就用默认 */ }
    return JSON.parse(JSON.stringify(DEFAULT));
  }
  function save() {
    try { localStorage.setItem('gto-holdem-v1', JSON.stringify(S)); } catch (e) { /* 无痕模式 */ }
  }

  function boardCount() { return S.board.filter((c) => c != null).length; }
  function boardCards() { return S.board.filter((c) => c != null); }
  function usedCards() { return S.hero.concat(S.board).filter((c) => c != null); }

  /* ============ 选项表 ============ */
  const PREFLOP_SCENARIOS = [
    { value: 'unopened', label: '前面都弃牌了', short: '我先开池',
      explain: '轮到你时还没人加注,你是第一个可以开池的人。' },
    { value: 'vs_raise', label: '前面有人加注', short: '有人加注',
      explain: '有人先加注了,你可以弃牌、跟注,或者再加一次(这叫 3bet)。' },
    { value: 'vs_limp', label: '有人只跟不加注', short: '有人跛入',
      explain: '有人只补了一个大盲的钱进池,没加注 —— 行话叫「跛入」。这种人通常牌不强,可以加注把他单独拎出来打。' },
    { value: 'vs_3bet', label: '我加注,被人再加', short: '我被 3bet',
      explain: '你先加注,后面有人又加了一次(3bet)。现在轮到你决定:弃牌、跟注,还是再加回去(4bet)。' },
    { value: 'vs_4bet', label: '我再加,又被加', short: '我被 4bet',
      explain: '你 3bet 之后对方又加了一次(4bet)。这个范围极紧,基本只有 KK+ 和 AK 才继续。' },
  ];
  const ROLES = [
    { value: 'opener', label: '他先加的注', short: '他开池',
      explain: '翻前是他第一个加注,你跟的。他的牌普遍偏强。' },
    { value: 'caller', label: '他跟了我的加注', short: '他跟注',
      explain: '翻前是你加注、他跟注。他的范围里没有最强的那批牌 —— 那些牌他会再加注。' },
    { value: '3bettor', label: '他翻前再加了我', short: '他 3bet',
      explain: '你加注后他又加了一次。范围很紧,但也掺着一些同花 A 之类的诈唬牌。' },
    { value: 'bbdefend', label: '他在大盲跟的', short: '大盲防守',
      explain: '你加注,大盲补钱跟下来。大盲防守范围非常宽,什么牌都可能有。' },
    { value: 'unknown', label: '记不清了', short: '不确定',
      explain: '按一个中等宽度(约 30%)的通用范围估算,准度会打折扣。' },
  ];
  const STREET_ACTS = [
    { value: 'none', label: '想不起来', short: '未记录' },
    { value: 'check', label: '他过牌', short: '过牌' },
    { value: 'call', label: '他跟注', short: '跟注' },
    { value: 'bet', label: '他下注', short: '下注' },
    { value: 'raise', label: '他加注', short: '加注' },
  ];
  const FACING = [
    { value: 'none', label: '还没人下注', short: '还没人下注',
      explain: '轮到你先说话,可以过牌或者下注。' },
    { value: 'check', label: '他过牌了', short: '他过牌',
      explain: '他把决定权交给你了。他过牌说明手里多半不是最强的牌。' },
    { value: 'bet', label: '他下注了', short: '他下注',
      explain: '你要么弃牌,要么补钱跟注,要么加注打回去。' },
    { value: 'raise', label: '他加注了', short: '他加注',
      explain: '你下注后他又加了一次 —— 这通常代表很强的牌或者坚决的诈唬。' },
  ];

  const shortOf = (list, v) => {
    const it = list.find((x) => x.value === v);
    return it ? (it.short || it.label) : String(v);
  };

  /* ============ 通用控件 ============ */
  function segmented(options, current, onPick, numeric) {
    const box = el('div', 'seg' + (numeric ? ' seg-num' : ''));
    for (const o of options) {
      const b = btn('seg-btn', o.label);
      b.setAttribute('aria-pressed', String(o.value === current));
      b.addEventListener('click', () => onPick(o.value));
      box.appendChild(b);
    }
    const cur = options.find((o) => o.value === current);
    if (cur && cur.explain) {
      const wrap = el('div', 'seg-wrap');
      wrap.appendChild(box);
      wrap.appendChild(el('p', 'seg-explain', cur.explain));
      return wrap;
    }
    return box;
  }

  function numberInput(value, opts, onChange) {
    const { step = 0.5, min = 0, max = 9999, decimals = 1 } = opts || {};
    const box = el('div', 'num');
    const minus = btn('num-btn', '−');
    minus.setAttribute('aria-label', '减少');
    const input = el('input', 'num-input');
    input.type = 'number';
    input.inputMode = 'decimal';
    input.step = String(step);
    input.value = String(value);
    const plus = btn('num-btn', '+');
    plus.setAttribute('aria-label', '增加');
    const clamp = (v) => Math.max(min, Math.min(max, v));
    const fire = (v) => {
      const r = +clamp(v).toFixed(decimals);
      input.value = String(r);
      onChange(r);
    };
    minus.addEventListener('click', () => fire(parseFloat(input.value || 0) - step));
    plus.addEventListener('click', () => fire(parseFloat(input.value || 0) + step));
    input.addEventListener('change', () => fire(parseFloat(input.value || 0)));
    box.append(minus, input, plus);
    return box;
  }

  function field(label, control) {
    const f = el('div', 'field');
    f.appendChild(el('span', 'field-label', label));
    f.appendChild(control);
    return f;
  }
  function moneyField(label, control) {
    const f = el('div', 'money-field');
    f.appendChild(el('span', 'money-label', label));
    f.appendChild(control);
    return f;
  }

  /* ============ 牌 ============ */
  let picker = null;

  function cardSlot(card, kind, index, placeholder) {
    const b = btn('card-slot' + (kind === 'hero' ? ' is-hero' : ''));
    if (card == null) {
      b.classList.add('is-empty');
      b.appendChild(el('span', 'card-rank', placeholder));
    } else {
      const suit = card & 3;
      b.classList.add(suit === 1 || suit === 2 ? 'red' : 'black');
      b.appendChild(el('span', 'card-rank', C.RANK_NAMES_CN[card >> 2]));
      b.appendChild(el('span', 'card-suit', C.SUIT_SYMBOLS[suit]));
    }
    if (picker && picker.kind === kind && picker.index === index) b.classList.add('is-active');
    b.setAttribute('aria-label', (kind === 'hero' ? '我的第' : '公共牌第') + (index + 1) + '张');
    b.addEventListener('click', () => openPicker(kind, index));
    return b;
  }

  function renderCards() {
    const line = $('cards-line');
    line.textContent = '';
    S.hero.forEach((c, i) => line.appendChild(cardSlot(c, 'hero', i, '我')));
    line.appendChild(el('div', 'card-divider'));
    S.board.forEach((c, i) => {
      line.appendChild(cardSlot(c, 'board', i, i < 3 ? '翻' : i === 3 ? '转' : '河'));
    });

    const n = boardCount();
    const strip = $('street-strip');
    strip.textContent = '';
    [{ n: 0, label: '翻前' }, { n: 3, label: '翻牌' }, { n: 4, label: '转牌' }, { n: 5, label: '河牌' }]
      .forEach((st, i) => {
        if (i) strip.appendChild(el('span', 'street-sep', '▸'));
        const cls = st.n === n ? ' is-now' : st.n < n ? ' is-done' : '';
        strip.appendChild(el('span', 'street-step' + cls, st.label));
      });
    if (n === 1 || n === 2) {
      strip.appendChild(el('span', 'street-sep', '·'));
      strip.appendChild(el('span', 'street-step', '还差 ' + (3 - n) + ' 张'));
    }
  }

  function openPicker(kind, index) {
    picker = { kind, index };
    renderCards();
    renderDeck();
    $('sheet-title').textContent = kind === 'hero'
      ? `我的第 ${index + 1} 张牌` : `公共牌第 ${index + 1} 张`;
    $('sheet').classList.add('open');
    $('sheet-mask').classList.add('open');
  }
  function closePicker() {
    picker = null;
    $('sheet').classList.remove('open');
    $('sheet-mask').classList.remove('open');
    renderCards();
  }

  function renderDeck() {
    const deck = $('deck');
    deck.textContent = '';
    const used = new Set(usedCards());
    if (picker) {
      used.delete(picker.kind === 'hero' ? S.hero[picker.index] : S.board[picker.index]);
    }
    for (let s = 0; s < 4; s++) {
      const row = el('div', 'deck-row');
      for (let r = 12; r >= 0; r--) {
        const card = r * 4 + s;
        const b = btn('deck-card ' + (s === 1 || s === 2 ? 'red' : 'black'));
        b.textContent = C.RANK_NAMES_CN[r] + C.SUIT_SYMBOLS[s];
        b.disabled = used.has(card);
        b.addEventListener('click', () => {
          if (!picker) return;
          if (picker.kind === 'hero') S.hero[picker.index] = card;
          else S.board[picker.index] = card;
          const arr = picker.kind === 'hero' ? S.hero : S.board;
          const next = picker.index + 1;
          if (next < arr.length && arr[next] == null) openPicker(picker.kind, next);
          else closePicker();
          onChange();
        });
        row.appendChild(b);
      }
      deck.appendChild(row);
    }
  }

  /* ============ 牌桌图(收在设置抽屉里) ============ */
  function villainSeatUsed() {
    if (boardCount() >= 3) return true;
    return ['vs_raise', 'vs_3bet', 'vs_4bet'].includes(S.scenario);
  }
  function villainKey() { return boardCount() >= 3 ? 'villainPos' : 'raiserPos'; }

  /** 座位环: 庄位摆正下方, 翻前行动从正上方顺时针推进 */
  function seatLayout(n) {
    const list = RG.positionsFor(n);
    let b = list.indexOf('BTN');
    if (b < 0) b = list.indexOf('SB'); // 单挑时小盲就是庄家
    const out = [];
    for (let i = 0; i < n; i++) {
      const th = ((90 + (i * 360) / n) * Math.PI) / 180;
      out.push({
        pos: list[(b + i) % n],
        x: 50 + 40 * Math.cos(th), y: 50 + 40 * Math.sin(th),
        bx: 50 + 25 * Math.cos(th), by: 50 + 25 * Math.sin(th),
        isButton: i === 0,
      });
    }
    return out;
  }

  function tableDiagram() {
    const seats = seatLayout(S.tableSize);
    const vPos = villainSeatUsed() ? S[villainKey()] : null;
    const target = villainSeatUsed() ? (S.seatTarget || 'hero') : 'hero';

    const wrap = el('div', 'tableviz');
    wrap.appendChild(el('div', 'tableviz-felt'));
    const center = el('div', 'tableviz-center');
    center.appendChild(el('div', 'tv-line-sm', S.tableSize + ' 人桌'));
    center.appendChild(el('div', 'tv-line-me', '我在 ' + S.heroPos));
    if (vPos) center.appendChild(el('div', 'tv-line-vs', '对手 ' + vPos));
    wrap.appendChild(center);

    for (const s of seats) {
      const isHero = s.pos === S.heroPos;
      const isVillain = s.pos === vPos;
      const b = btn('seat' + (isHero ? ' is-hero' : '') + (isVillain ? ' is-villain' : ''));
      b.textContent = s.pos;
      b.style.left = s.x + '%';
      b.style.top = s.y + '%';
      b.setAttribute('aria-pressed', String(target === 'hero' ? isHero : isVillain));
      b.setAttribute('aria-label', RG.POS_LABEL[s.pos] + (isHero ? ',我的位置' : isVillain ? ',对手位置' : ''));
      b.addEventListener('click', () => selectSeat(s.pos));
      wrap.appendChild(b);
      if (s.isButton) {
        const d = el('div', 'dealer-btn', 'D');
        d.style.left = s.bx + '%';
        d.style.top = s.by + '%';
        d.title = '庄家按钮';
        wrap.appendChild(d);
      }
    }
    return wrap;
  }

  function selectSeat(pos) {
    const list = RG.positionsFor(S.tableSize);
    const target = villainSeatUsed() ? (S.seatTarget || 'hero') : 'hero';
    if (target === 'villain') {
      if (pos === S.heroPos) return; // 对手不能和自己同座
      S[villainKey()] = pos;
    } else {
      S.heroPos = pos;
      if (S.villainPos === pos) S.villainPos = list.find((p) => p !== pos);
      if (S.raiserPos === pos) S.raiserPos = list.find((p) => p !== pos);
    }
    onChange();
    renderSetupSheet();
  }

  function renderSetupSheet() {
    const box = $('setup-body');
    box.textContent = '';
    const sizes = [];
    for (let i = 2; i <= 9; i++) sizes.push({ value: i, label: String(i) });
    box.appendChild(field('几个人', segmented(sizes, S.tableSize, (v) => {
      S.tableSize = v;
      const list = RG.positionsFor(v);
      if (!list.includes(S.heroPos)) S.heroPos = list[list.length - 1];
      if (!list.includes(S.villainPos) || S.villainPos === S.heroPos) S.villainPos = list.find((p) => p !== S.heroPos);
      if (!list.includes(S.raiserPos) || S.raiserPos === S.heroPos) S.raiserPos = list.find((p) => p !== S.heroPos);
      onChange(); renderSetupSheet();
    }, true)));

    if (villainSeatUsed()) {
      box.appendChild(field('点座位是在设定谁', segmented([
        { value: 'hero', label: '我的位置' },
        { value: 'villain', label: '对手位置' },
      ], S.seatTarget || 'hero', (v) => { S.seatTarget = v; renderSetupSheet(); })));
    }
    box.appendChild(tableDiagram());
    box.appendChild(field('有效筹码 (bb)', numberInput(S.effStack,
      { step: 5, min: 5, max: 1000, decimals: 0 }, (v) => { S.effStack = v; onChange(); })));
    box.appendChild(el('p', 'hint', '这些一局里基本不变,设好收起来就行。'));
  }

  /* ============ 局面短语 ============ */
  function chipDefs() {
    const n = boardCount();
    const positions = RG.positionsFor(S.tableSize)
      .filter((p) => p !== S.heroPos).map((p) => ({ value: p, label: p }));
    const defs = [];

    if (n < 3) {
      defs.push({
        id: 'scenario', key: '局面', val: shortOf(PREFLOP_SCENARIOS, S.scenario),
        title: '轮到我时是什么情况', options: PREFLOP_SCENARIOS, cur: S.scenario,
        set: (v) => { S.scenario = v; S.potTouched = false; },
      });
      if (['vs_raise', 'vs_3bet', 'vs_4bet'].includes(S.scenario)) {
        defs.push({
          id: 'raiser', key: '对手在', val: S.raiserPos,
          title: '加注的人坐在哪', options: positions, cur: S.raiserPos,
          set: (v) => { S.raiserPos = v; },
        });
      }
      if (S.scenario === 'vs_raise') {
        defs.push({
          id: 'callers', key: '中间跟注', val: S.callers + ' 人',
          title: '他加注之后、轮到我之前有几个人跟了', cur: S.callers,
          options: [0, 1, 2, 3].map((i) => ({ value: i, label: i + ' 人' })),
          set: (v) => { S.callers = v; S.potTouched = false; },
        });
      }
      if (S.scenario === 'vs_limp') {
        defs.push({
          id: 'limpers', key: '跛入', val: S.limpers + ' 人',
          title: '有几个人只跟不加注', cur: S.limpers,
          options: [1, 2, 3, 4].map((i) => ({ value: i, label: i + ' 人' })),
          set: (v) => { S.limpers = v; S.potTouched = false; },
        });
      }
    } else {
      defs.push({
        id: 'villains', key: '对手', val: S.villains + ' 人',
        title: '还有几个人在牌局里', cur: S.villains,
        options: [1, 2, 3].map((i) => ({ value: i, label: i + ' 人' })),
        set: (v) => { S.villains = v; },
      });
      defs.push({
        id: 'villainPos', key: '他在', val: S.villainPos,
        title: '主要那个对手坐在哪', options: positions, cur: S.villainPos,
        set: (v) => { S.villainPos = v; },
      });
      defs.push({
        id: 'role', key: '他翻前', val: shortOf(ROLES, S.villainRole),
        title: '他翻前是什么身份', options: ROLES, cur: S.villainRole,
        set: (v) => { S.villainRole = v; },
      });
      if (n >= 4) {
        defs.push({
          id: 'h_flop', key: '翻牌他', val: shortOf(STREET_ACTS, S.history.flop),
          title: '翻牌圈他做了什么', options: STREET_ACTS, cur: S.history.flop,
          set: (v) => { S.history.flop = v; },
        });
      }
      if (n >= 5) {
        defs.push({
          id: 'h_turn', key: '转牌他', val: shortOf(STREET_ACTS, S.history.turn),
          title: '转牌圈他做了什么', options: STREET_ACTS, cur: S.history.turn,
          set: (v) => { S.history.turn = v; },
        });
      }
      defs.push({
        id: 'facing', key: '现在', val: shortOf(FACING, S.facing),
        title: '轮到我时面对什么', options: FACING, cur: S.facing,
        set: (v) => {
          S.facing = v;
          if (v === 'none' || v === 'check') S.toCallBB = 0;
          else if (!S.toCallBB) S.toCallBB = +(S.potBB * 0.5).toFixed(1);
        },
      });
    }
    return defs;
  }

  function renderChips() {
    const box = $('sit-chips');
    box.textContent = '';
    const defs = chipDefs();
    if (!defs.some((d) => d.id === openChip)) openChip = null;

    for (const d of defs) {
      const b = btn('chip' + (openChip === d.id ? ' is-open' : ''));
      b.appendChild(el('span', 'chip-key', d.key));
      b.appendChild(el('span', 'chip-val', d.val));
      b.addEventListener('click', () => {
        openChip = openChip === d.id ? null : d.id;
        renderChips();
      });
      box.appendChild(b);
    }

    const panel = $('chip-panel');
    panel.textContent = '';
    const cur = defs.find((d) => d.id === openChip);
    if (!cur) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    panel.appendChild(el('div', 'chip-panel-title', cur.title));
    const opts = el('div', 'opts');
    for (const o of cur.options) {
      const b = btn('opt', o.label);
      b.setAttribute('aria-pressed', String(o.value === cur.cur));
      b.addEventListener('click', () => {
        cur.set(o.value);
        openChip = null;
        onChange();
      });
      opts.appendChild(b);
    }
    panel.appendChild(opts);
    const sel = cur.options.find((o) => o.value === cur.cur);
    if (sel && sel.explain) panel.appendChild(el('p', 'opt-explain', sel.explain));
  }

  /* ============ 钱 ============ */
  function openSizeFor(pos) {
    if (S.tableSize >= 8 && ['UTG', 'UTG1', 'UTG2', 'MP'].includes(pos)) return 2.5;
    if (pos === 'SB') return 3;
    if (pos === 'BTN' || pos === 'CO') return 2.3;
    return 2.5;
  }

  /** 进翻牌圈时按翻前动作估一个底池, 用户随时能改 */
  function autoPotPostflop() {
    let pot;
    switch (S.scenario) {
      case 'unopened': pot = openSizeFor(S.heroPos) * 2 + 0.5; break;
      case 'vs_limp': pot = (3 + S.limpers) * 2 + 0.5; break;
      case 'vs_raise': pot = S.openSizeBB * (2 + S.callers) + 1.5; break;
      case 'vs_3bet': pot = S.threeBetBB * 2 + 0.5; break;
      case 'vs_4bet': pot = S.fourBetBB * 2 + 0.5; break;
      default: pot = 6;
    }
    S.potBB = +pot.toFixed(1);
    if (S.facing === 'bet' || S.facing === 'raise') {
      if (!S.toCallBB) S.toCallBB = +(S.potBB * 0.5).toFixed(1);
    } else S.toCallBB = 0;
  }

  function autoPot() {
    if (S.potTouched) return;
    const n = boardCount();
    if (n >= 3) { autoPotPostflop(); return; }
    const blinds = 1.5;
    const inBlind = S.heroPos === 'BB' ? 1 : S.heroPos === 'SB' ? 0.5 : 0;
    switch (S.scenario) {
      case 'unopened':
        S.potBB = blinds;
        S.toCallBB = S.heroPos === 'SB' ? 0.5 : 0;
        break;
      case 'vs_limp':
        S.potBB = +(blinds + S.limpers).toFixed(1);
        S.toCallBB = +(1 - inBlind).toFixed(1);
        break;
      case 'vs_raise':
        S.potBB = +(blinds + S.openSizeBB * (1 + S.callers)).toFixed(1);
        S.toCallBB = +(S.openSizeBB - inBlind).toFixed(1);
        break;
      case 'vs_3bet':
        S.potBB = +(blinds + S.openSizeBB + S.threeBetBB).toFixed(1);
        S.toCallBB = +(S.threeBetBB - S.openSizeBB).toFixed(1);
        break;
      case 'vs_4bet':
        S.potBB = +(blinds + S.threeBetBB + S.fourBetBB).toFixed(1);
        S.toCallBB = +(S.fourBetBB - S.threeBetBB).toFixed(1);
        break;
    }
  }

  function heroInvested() {
    if (boardCount() >= 3) return 0;
    if (S.scenario === 'vs_3bet') return S.openSizeBB;
    if (S.scenario === 'vs_4bet') return S.threeBetBB;
    if (S.heroPos === 'BB') return 1;
    if (S.heroPos === 'SB') return 0.5;
    return 0;
  }

  function renderMoney() {
    autoPot();
    const box = $('money');
    box.textContent = '';
    const n = boardCount();

    if (n < 3) {
      if (S.scenario === 'vs_raise') {
        box.appendChild(moneyField('他加注到', numberInput(S.openSizeBB, { step: 0.5, min: 1 },
          (v) => { S.openSizeBB = v; S.potTouched = false; onChange(); })));
      } else if (S.scenario === 'vs_3bet') {
        box.appendChild(moneyField('我开池到', numberInput(S.openSizeBB, { step: 0.5, min: 1 },
          (v) => { S.openSizeBB = v; S.potTouched = false; onChange(); })));
        box.appendChild(moneyField('他加到', numberInput(S.threeBetBB, { step: 0.5, min: 2 },
          (v) => { S.threeBetBB = v; S.potTouched = false; onChange(); })));
      } else if (S.scenario === 'vs_4bet') {
        box.appendChild(moneyField('我加到', numberInput(S.threeBetBB, { step: 0.5, min: 2 },
          (v) => { S.threeBetBB = v; S.potTouched = false; onChange(); })));
        box.appendChild(moneyField('他加到', numberInput(S.fourBetBB, { step: 1, min: 4 },
          (v) => { S.fourBetBB = v; S.potTouched = false; onChange(); })));
      }
    }

    box.appendChild(moneyField('底池 bb', numberInput(S.potBB, { step: 0.5, min: 0.5 },
      (v) => { S.potBB = v; S.potTouched = true; onChange(); })));

    const facingBet = n >= 3 ? (S.facing === 'bet' || S.facing === 'raise') : S.toCallBB > 0;
    if (facingBet) {
      box.appendChild(moneyField('我要跟 bb', numberInput(S.toCallBB, { step: 0.5, min: 0 },
        (v) => { S.toCallBB = v; S.potTouched = true; onChange(); })));
    }

    if (n >= 3 && facingBet) {
      const q = el('div', 'quick');
      [['⅓ 池', 1 / 3], ['½ 池', 0.5], ['⅔ 池', 2 / 3], ['满池', 1], ['1.5 池', 1.5]].forEach(([lbl, f]) => {
        const b = btn('quick-btn', lbl);
        b.addEventListener('click', () => {
          S.toCallBB = +(S.potBB * f).toFixed(1);
          S.potTouched = true;
          onChange();
        });
        q.appendChild(b);
      });
      box.appendChild(q);
    }
  }

  /* ============ 判决区(常驻底部) ============ */
  function renderDock(res) {
    const dock = $('dock');
    dock.textContent = '';
    const inner = el('div', 'dock-inner');
    dock.appendChild(inner);

    if (!res) {
      const n = boardCount();
      inner.appendChild(el('div', 'dock-empty',
        (S.hero[0] == null || S.hero[1] == null)
          ? '先点上面的牌位,选你的两张底牌'
          : `公共牌要么留空(翻前),要么填满 3 / 4 / 5 张。现在是 ${n} 张。`));
      measureDock();
      return;
    }

    const sorted = res.actions.slice().sort((a, b) => b.freq - a.freq);
    const best = sorted[0];

    const top = el('div', 'dock-top');
    const main = el('div', 'dock-main');
    const act = el('div', 'dock-action act-' + best.key);
    act.appendChild(el('span', null, best.label));
    if (best.tag) act.appendChild(el('span', 'act-tag', best.tag));
    main.appendChild(act);
    const mixed = sorted.filter((a) => a.freq > 0.02).length > 1;
    main.appendChild(el('div', 'dock-sub',
      `${(best.freq * 100).toFixed(0)}% 频率 · ${mixed ? '混合策略' : '纯策略'}`));
    top.appendChild(main);

    const eq = el('div', 'dock-eq');
    eq.appendChild(el('div', 'dock-eq-val', (res.equity * 100).toFixed(1) + '%'));
    eq.appendChild(el('div', 'dock-eq-lbl', '我的胜率'));
    top.appendChild(eq);
    inner.appendChild(top);

    const bar = el('div', 'freqbar');
    bar.setAttribute('role', 'img');
    bar.setAttribute('aria-label', sorted.map((a) => `${ACT_LABEL[a.key]} ${(a.freq * 100).toFixed(0)}%`).join('、'));
    for (const a of res.actions) {
      if (a.freq < 0.005) continue;
      const seg = el('div', 'freqbar-seg bg-' + a.key);
      seg.style.flexGrow = String(a.freq);
      seg.style.flexBasis = '0';
      if (a.freq > 0.14) seg.textContent = ACT_LABEL[a.key] + ' ' + Math.round(a.freq * 100) + '%';
      bar.appendChild(seg);
    }
    inner.appendChild(bar);

    const acts = el('div', 'dock-acts');
    for (const a of sorted) {
      const row = el('div', 'dock-act');
      const nm = el('div', 'dock-act-name act-' + a.key);
      nm.appendChild(el('span', null, a.label));
      if (a.tag) nm.appendChild(el('span', 'act-tag', a.tag));
      row.appendChild(nm);
      row.appendChild(el('div', 'dock-act-freq', (a.freq * 100).toFixed(0) + '%'));
      row.appendChild(el('div', 'dock-act-ev ' + (a.ev > 0.001 ? 'ev-pos' : 'ev-neg'),
        a.ev == null ? '—' : (a.ev >= 0 ? '+' : '') + a.ev.toFixed(2)));
      acts.appendChild(row);
    }
    inner.appendChild(acts);
    measureDock();
  }

  function measureDock() {
    document.documentElement.style.setProperty('--dock-h', $('dock').offsetHeight + 'px');
  }

  /* ============ 详情标签页 ============ */
  const TABS = [
    { id: 'nums', label: '数字' },
    { id: 'range', label: '他的牌' },
    { id: 'why', label: '为什么' },
    { id: 'ai', label: 'AI 教练' },
  ];

  function renderTabs() {
    const box = $('det-tabs');
    box.textContent = '';
    for (const t of TABS) {
      const b = btn('tab' + (tab === t.id ? ' is-on' : ''), t.label);
      b.addEventListener('click', () => { tab = t.id; renderTabs(); renderTabBody(lastResult); });
      box.appendChild(b);
    }
  }

  function renderTabBody(res) {
    const box = $('det-body');
    box.textContent = '';
    if (tab === 'ai') { renderAITab(box); return; }
    if (!res) {
      box.appendChild(el('p', 'hint', '牌填好之后,这里会出现详细数字。'));
      return;
    }
    if (tab === 'nums') renderStats(box, res);
    else if (tab === 'range') renderRange(box, res);
    else if (tab === 'why') renderReasons(box, res);
  }

  function renderStats(box, res) {
    const m = res.metrics;
    const grid = el('div', 'stats');
    const items = [];
    items.push({ v: (m.equity * 100).toFixed(1) + '%', l: res.eqVsRandom ? '对随机牌胜率' : '我的胜率', term: '胜率' });
    if (m.required > 0) {
      items.push({
        v: (m.required * 100).toFixed(1) + '%', l: '跟注要多少', term: '跟注所需胜率',
        cls: m.equity >= m.required ? 'good' : 'bad',
      });
      items.push({
        v: (m.equity - m.required >= 0 ? '+' : '') + ((m.equity - m.required) * 100).toFixed(1) + 'pt',
        l: '够不够', term: '胜率盈余', cls: m.equity >= m.required ? 'good' : 'bad',
      });
    }
    if (m.potOdds) items.push({ v: m.potOdds.toFixed(1) + ' : 1', l: '底池赔率', term: '底池赔率' });
    if (m.mdf != null) items.push({ v: (m.mdf * 100).toFixed(0) + '%', l: '至少要防守', term: 'MDF 最低防守频率' });
    items.push({ v: m.spr.toFixed(1), l: '筹码底池比', term: 'SPR 筹码底池比' });
    if (m.outs) items.push({ v: String(m.outs), l: '还有几张补牌', term: '补牌' });
    if (m.percentile != null) {
      items.push({
        v: (m.percentile * 100).toFixed(0) + '%',
        l: res.street === 'preflop' ? '强于其余起手牌' : '强于牌面其余组合',
      });
    }
    for (const it of items.slice(0, 6)) {
      const s = btn('stat' + (it.cls ? ' ' + it.cls : ''));
      s.appendChild(el('div', 'stat-val', it.v));
      const lbl = el('div', 'stat-lbl', it.l);
      if (it.term) lbl.appendChild(el('span', 'stat-q', '?'));
      s.appendChild(lbl);
      if (it.term) {
        s.addEventListener('click', () => openGlossary(it.term));
        s.setAttribute('aria-label', it.l + ' ' + it.v + ',点开看解释');
      } else s.classList.add('is-plain');
      grid.appendChild(s);
    }
    box.appendChild(grid);
    box.appendChild(el('p', 'hint', '带 ? 的点一下有大白话解释。'));
  }

  function renderRange(box, res) {
    box.appendChild(el('p', 'hint', res.villainLabel || ''));
    const scroll = el('div', 'grid-scroll');
    const grid = el('div', 'rangegrid');
    const range = res.villainRange || {};
    const heroKey = (S.hero[0] != null && S.hero[1] != null) ? RG.handKey(S.hero[0], S.hero[1]) : null;
    const order = [];
    for (let r = 12; r >= 0; r--) order.push(r);
    for (const hi of order) {
      for (const lo of order) {
        let key;
        if (hi === lo) key = C.RANK_CHARS[hi] + C.RANK_CHARS[hi];
        else if (hi > lo) key = C.RANK_CHARS[hi] + C.RANK_CHARS[lo] + 's';
        else key = C.RANK_CHARS[lo] + C.RANK_CHARS[hi] + 'o';
        const f = range[key] || 0;
        const cell = el('div', 'rg-cell' + (f > 0.5 ? ' on' : '') + (key === heroKey ? ' hero' : ''));
        cell.textContent = key;
        if (f > 0.01) cell.style.background = `rgba(var(--brass-rgb), ${(0.14 + f * 0.86).toFixed(3)})`;
        cell.title = `${key} · ${(f * 100).toFixed(0)}%`;
        grid.appendChild(cell);
      }
    }
    scroll.appendChild(grid);
    box.appendChild(scroll);

    const lg = el('div', 'legend');
    const item = (bg, txt) => {
      const i = el('span', 'legend-item');
      const sw = el('span', 'legend-swatch');
      sw.style.background = bg;
      i.append(sw, document.createTextNode(txt));
      return i;
    };
    lg.append(
      item('rgba(var(--brass-rgb),1)', '一定有'),
      item('rgba(var(--brass-rgb),.45)', '部分频率'),
      item('var(--surface-2)', '已排除'));
    lg.appendChild(el('span', 'legend-item', '右上=同花 左下=非同花 对角=对子'));
    box.appendChild(lg);
  }

  function renderReasons(box, res) {
    const ul = el('ul', 'reasons');
    for (const r of res.reasons) {
      const li = el('li', 'reason');
      li.appendChild(el('span', null, r));
      ul.appendChild(li);
    }
    if (S.villains > 1 && boardCount() >= 3) {
      const li = el('li', 'reason');
      li.appendChild(el('span', null,
        `多人底池(${S.villains} 个对手)里诈唬成功率明显下降,加注频率要再往下调,价值下注也要更收紧。`));
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  /* ============ AI 教练 ============ */
  const AI_DEFAULT = { provider: 'deepseek', apiKey: '', model: 'deepseek-chat', baseUrl: '', temperature: 0.6 };
  let AI = loadAI();
  let aiAbort = null;
  let aiLast = { answer: '', think: '', error: '' };

  function loadAI() {
    try {
      const raw = localStorage.getItem('gto-holdem-ai-v1');
      if (raw) return Object.assign({}, AI_DEFAULT, JSON.parse(raw));
    } catch (e) { /* 缓存坏了就用默认 */ }
    return Object.assign({}, AI_DEFAULT);
  }
  function saveAI() {
    try { localStorage.setItem('gto-holdem-ai-v1', JSON.stringify(AI)); } catch (e) { /* 无痕模式 */ }
  }
  function aiConfigured() { return !!(AI.apiKey && AI.model); }

  const AI_PRESETS = [
    { q: '为什么这么打?讲讲背后的道理', label: '为什么这么打' },
    { q: '对手是那种很爱跟注不肯弃牌的鱼,我该怎么调整?', label: '对手爱跟注' },
    { q: '对手很紧很凶,只有大牌才动手,我该怎么调整?', label: '对手很紧' },
    { q: '下一条街我该怎么计划?什么牌来了我要小心?', label: '下一条街' },
    { q: '我这手牌最常见的打错方式是什么?', label: '常见错误' },
  ];

  function renderAITab(box) {
    const wrap = el('div', 'ai-wrap');
    if (!aiConfigured()) {
      wrap.appendChild(el('p', 'hint',
        '配一个大模型的 API Key,它就能结合上面算出来的数字,用人话给你讲这手牌该怎么想。'));
      const b = btn('quick-btn', '去填 API Key');
      b.addEventListener('click', openAISheet);
      wrap.appendChild(b);
      box.appendChild(wrap);
      return;
    }

    const presets = el('div', 'quick');
    for (const p of AI_PRESETS) {
      const b = btn('quick-btn', p.label);
      b.addEventListener('click', () => askAI(p.q));
      presets.appendChild(b);
    }
    wrap.appendChild(presets);

    const ask = el('div', 'ai-ask');
    const input = el('input', 'text-input');
    input.type = 'text';
    input.placeholder = '也可以自己问,比如:他转牌继续开火怎么办?';
    const fire = () => {
      const v = input.value.trim();
      if (v) { input.value = ''; askAI(v); }
    };
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); fire(); } });
    const send = btn('ai-send', '问');
    send.addEventListener('click', fire);
    ask.append(input, send);
    wrap.appendChild(ask);

    if (aiLast.think) {
      const d = el('details', 'ai-think');
      d.appendChild(el('summary', null, '模型的思考过程'));
      d.appendChild(el('div', null, aiLast.think));
      wrap.appendChild(d);
    }
    if (aiLast.error) wrap.appendChild(el('div', 'ai-answer is-error', aiLast.error));
    else if (aiLast.answer) wrap.appendChild(el('div', 'ai-answer', aiLast.answer));
    box.appendChild(wrap);
  }

  async function askAI(question) {
    if (!lastResult) {
      aiLast = { answer: '', think: '', error: '先把手牌填完,让本地引擎算出结果,我才能把材料交给模型。' };
      tab = 'ai'; renderTabs(); renderTabBody(lastResult);
      return;
    }
    if (aiAbort) aiAbort.abort();
    aiAbort = new AbortController();
    aiLast = { answer: '正在想…', think: '', error: '' };
    tab = 'ai';
    renderTabs();
    renderTabBody(lastResult);

    const messages = [
      { role: 'system', content: G.ai.SYSTEM_PROMPT },
      { role: 'user', content: G.ai.buildContext(lastResult, snapshotForAI()) + '\n\n【我的问题】' + question },
    ];

    let first = true, paint = null;
    const repaint = () => {
      if (paint) return;
      paint = setTimeout(() => {
        paint = null;
        if (tab === 'ai') renderTabBody(lastResult);
      }, 60);
    };
    try {
      await G.ai.chat(AI, messages, (text, kind) => {
        if (kind === 'reasoning') { aiLast.think += text; repaint(); return; }
        if (first) { aiLast.answer = ''; first = false; }
        aiLast.answer += text;
        repaint();
      }, aiAbort.signal);
      if (first) aiLast.answer = '模型没有返回内容。';
    } catch (e) {
      if (e.name === 'AbortError') return;
      aiLast.answer = '';
      aiLast.error = G.ai.explainError(e);
    }
    if (tab === 'ai') renderTabBody(lastResult);
  }

  function snapshotForAI() {
    const n = boardCount();
    const scen = PREFLOP_SCENARIOS.find((s) => s.value === S.scenario);
    let villainDesc = '';
    if (n >= 3) {
      const role = ROLES.find((r) => r.value === S.villainRole);
      villainDesc = `${S.villains} 个对手,主要那个在 ${S.villainPos}` +
        (role ? `,翻前是「${role.label}」` : '') +
        (S.facing === 'bet' ? ',这条街他下注了' : S.facing === 'raise' ? ',这条街他加注了'
          : S.facing === 'check' ? ',这条街他过牌了' : ',还没人下注');
    } else if (S.scenario !== 'unopened') {
      villainDesc = `加注的人在 ${S.raiserPos}`;
    }
    return {
      tableSize: S.tableSize, heroPos: S.heroPos, effStack: S.effStack,
      hero: S.hero.filter((c) => c != null), board: boardCards(),
      potBB: S.potBB,
      toCallBB: (n >= 3 && (S.facing === 'none' || S.facing === 'check')) ? 0 : S.toCallBB,
      scenarioText: scen ? scen.label : S.scenario,
      villainDesc,
    };
  }

  function renderAIConfig() {
    const box = $('ai-cfg');
    box.textContent = '';
    const P = G.ai.PROVIDERS;
    const refreshTab = () => { if (tab === 'ai') renderTabBody(lastResult); };

    box.appendChild(field('服务商', segmented(
      Object.keys(P).map((k) => ({ value: k, label: P[k].name })), AI.provider,
      (v) => {
        AI.provider = v;
        const first = P[v].models[0];
        if (first) AI.model = first.id;
        saveAI(); renderAIConfig(); refreshTab();
      })));

    const prov = P[AI.provider];
    if (prov.custom) {
      const bu = el('input', 'text-input');
      bu.type = 'url';
      bu.placeholder = '例如 https://openrouter.ai/api/v1';
      bu.value = AI.baseUrl || '';
      bu.addEventListener('input', () => { AI.baseUrl = bu.value.trim(); saveAI(); });
      box.appendChild(field('接口地址(不含 /chat/completions)', bu));
    }

    // API Key 由使用者自己填, 只留在本机浏览器
    const keyWrap = el('div', 'key-row');
    const key = el('input', 'text-input');
    key.type = 'password';
    key.autocomplete = 'off';
    key.spellcheck = false;
    key.placeholder = prov.keyHint || 'API Key';
    key.value = AI.apiKey || '';
    key.addEventListener('input', () => { AI.apiKey = key.value.trim(); saveAI(); refreshTab(); });
    const eye = btn('quick-btn', '显示');
    eye.addEventListener('click', () => {
      key.type = key.type === 'password' ? 'text' : 'password';
      eye.textContent = key.type === 'password' ? '显示' : '隐藏';
    });
    keyWrap.append(key, eye);
    box.appendChild(field('API Key' + (prov.keyUrl ? `(去 ${prov.keyUrl} 申请)` : ''), keyWrap));

    if (prov.models.length) {
      box.appendChild(field('模型', segmented(
        prov.models.map((m) => ({ value: m.id, label: m.label, explain: m.note })), AI.model,
        (v) => { AI.model = v; saveAI(); renderAIConfig(); refreshTab(); })));
      const other = el('input', 'text-input');
      other.type = 'text';
      other.placeholder = '或者手填一个模型名';
      other.value = prov.models.some((m) => m.id === AI.model) ? '' : AI.model;
      other.addEventListener('change', () => {
        if (other.value.trim()) { AI.model = other.value.trim(); saveAI(); renderAIConfig(); refreshTab(); }
      });
      box.appendChild(other);
    } else {
      const mi = el('input', 'text-input');
      mi.type = 'text';
      mi.placeholder = '模型名,例如 deepseek-chat';
      mi.value = AI.model || '';
      mi.addEventListener('input', () => { AI.model = mi.value.trim(); saveAI(); refreshTab(); });
      box.appendChild(field('模型名', mi));
    }

    const row = el('div', 'quick');
    const status = el('p', 'ai-status');
    const test = btn('quick-btn', '测试连接');
    test.addEventListener('click', async () => {
      if (!aiConfigured()) {
        status.textContent = '先把 API Key 和模型名填上。';
        status.className = 'ai-status bad';
        return;
      }
      status.textContent = '正在测试…';
      status.className = 'ai-status';
      test.disabled = true;
      try {
        const r = await G.ai.testKey(AI);
        if (r.ok) { status.textContent = '通了,可以用了。'; status.className = 'ai-status good'; }
        else {
          status.textContent = G.ai.explainError({ kind: 'http', status: r.status, message: r.message });
          status.className = 'ai-status bad';
        }
      } catch (e) {
        status.textContent = G.ai.explainError({ kind: 'blocked', detail: e.message });
        status.className = 'ai-status bad';
      }
      test.disabled = false;
      refreshTab();
    });
    const clear = btn('quick-btn', '清除 Key');
    clear.addEventListener('click', () => { AI.apiKey = ''; saveAI(); renderAIConfig(); refreshTab(); });
    row.append(test, clear);
    box.append(row, status);
    box.appendChild(el('p', 'hint',
      'Key 只存在这台设备的浏览器里 —— 提问时由你的浏览器直接发给服务商,不经过中转。建议用一个设了额度上限的 Key。'));
  }

  /* ============ 术语表 ============ */
  function renderGlossary(filter, highlight) {
    const body = $('gloss-body');
    body.textContent = '';
    const q = (filter || '').trim().toLowerCase();
    let hit = null, shown = 0;
    for (const g of G.glossary.GROUPS) {
      const items = g.items.filter((it) => !q ||
        it.term.toLowerCase().includes(q) ||
        it.en.toLowerCase().includes(q) ||
        it.plain.toLowerCase().includes(q));
      if (!items.length) continue;
      body.appendChild(el('div', 'gloss-group', g.name));
      for (const it of items) {
        shown++;
        const card = el('div', 'gloss-item' + (it.term === highlight ? ' is-hit' : ''));
        const head = el('div', 'gloss-term');
        head.appendChild(el('span', 'gloss-cn', it.term));
        head.appendChild(el('span', 'gloss-en', it.en));
        card.appendChild(head);
        card.appendChild(el('p', 'gloss-plain', it.plain));
        if (it.more) card.appendChild(el('p', 'gloss-more', it.more));
        body.appendChild(card);
        if (it.term === highlight) hit = card;
      }
    }
    if (!shown) body.appendChild(el('p', 'hint', '没找到这个词。试试「跛入」「SPR」「听牌」「范围」。'));
    if (hit) setTimeout(() => hit.scrollIntoView({ block: 'center' }), 60);
  }

  /* ============ 抽屉开关 ============ */
  const openSheet = (id) => { $(id + '-sheet').classList.add('open'); $(id + '-mask').classList.add('open'); };
  const closeSheet = (id) => { $(id + '-sheet').classList.remove('open'); $(id + '-mask').classList.remove('open'); };

  function openGlossary(term) {
    $('gloss-search').value = '';
    renderGlossary('', term);
    $('gloss-title').textContent = term || '术语表';
    openSheet('gloss');
  }
  function openAISheet() { renderAIConfig(); openSheet('ai'); }
  function openSetup() { renderSetupSheet(); openSheet('setup'); }

  /* ============ 计算 ============ */
  let timer = null;
  function scheduleCompute() {
    clearTimeout(timer);
    // 不要用 requestAnimationFrame — 页面在后台时它不触发, 结果会一直不刷新
    timer = setTimeout(compute, 80);
  }

  function compute() {
    const board = boardCards();
    const n = board.length;
    if (S.hero[0] == null || S.hero[1] == null || n === 1 || n === 2) {
      lastResult = null;
      renderDock(null);
      renderTabBody(null);
      return;
    }

    const street = n === 0 ? 'preflop' : n === 3 ? 'flop' : n === 4 ? 'turn' : 'river';
    const villainPos = n >= 3 ? S.villainPos : S.raiserPos;
    const ctx = {
      tableSize: S.tableSize, heroPos: S.heroPos,
      hero: [S.hero[0], S.hero[1]], board, street,
      effStack: S.effStack, potBB: S.potBB,
      toCallBB: (n >= 3 && (S.facing === 'none' || S.facing === 'check')) ? 0 : S.toCallBB,
      scenario: S.scenario, raiserPos: S.raiserPos, openSizeBB: S.openSizeBB,
      callers: S.callers, limpers: S.limpers,
      villains: n >= 3 ? S.villains : (S.scenario === 'unopened' ? 1 : 1 + S.callers),
      villainRole: S.villainRole, villainPos,
      history: S.history,
      facing: n >= 3 ? S.facing : 'none',
      inPosition: RG.isInPosition(S.heroPos, villainPos),
      heroInvested: heroInvested(),
    };

    let res;
    try {
      res = AD.analyze(ctx);
    } catch (err) {
      lastResult = null;
      renderDock(null);
      const box = $('det-body');
      box.textContent = '';
      box.appendChild(el('p', 'hint', '计算出错:' + err.message));
      return;
    }
    lastResult = res;
    renderDock(res);
    renderTabBody(res);
  }

  /* ============ 驱动 ============ */
  function onChange() {
    const n = boardCount();
    // 换街了 → 底池要重估, 展开的短语也收起来
    if (S.lastStreetN !== n) { S.lastStreetN = n; S.potTouched = false; openChip = null; }
    save();
    $('setup-summary').textContent = `${S.tableSize} 人 · 我在 ${S.heroPos} · ${S.effStack}bb`;
    renderCards();
    renderChips();
    renderMoney();
    scheduleCompute();
  }

  function init() {
    $('btn-setup').addEventListener('click', openSetup);
    $('setup-close').addEventListener('click', () => closeSheet('setup'));
    $('setup-mask').addEventListener('click', () => closeSheet('setup'));
    $('btn-ai').addEventListener('click', openAISheet);
    $('ai-close').addEventListener('click', () => closeSheet('ai'));
    $('ai-mask').addEventListener('click', () => closeSheet('ai'));
    $('btn-glossary').addEventListener('click', () => openGlossary(null));
    $('gloss-close').addEventListener('click', () => closeSheet('gloss'));
    $('gloss-mask').addEventListener('click', () => closeSheet('gloss'));
    $('gloss-search').addEventListener('input', (e) => renderGlossary(e.target.value, null));
    $('sheet-close').addEventListener('click', closePicker);
    $('sheet-mask').addEventListener('click', closePicker);
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      closePicker();
      ['gloss', 'ai', 'setup'].forEach(closeSheet);
    });
    window.addEventListener('resize', measureDock);

    renderTabs();
    onChange();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})(typeof globalThis !== 'undefined' ? globalThis : this);
