/* ============================================================
   ranges.js — 169 种起手牌 / 范围解析 / 翻前图表
   范围表示: { 'AKs': 1, 'QQ': 1, 'A5s': 0.5, … } 频率 0~1
   ============================================================ */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});
  const C = G.cards;
  const R = C.RANK_CHARS; // '23456789TJQKA'

  /* ---------- 169 手牌基础 ---------- */
  const ALL_HANDS = [];
  for (let hi = 12; hi >= 0; hi--) {
    for (let lo = 12; lo >= 0; lo--) {
      if (hi === lo) { if (hi >= lo) ALL_HANDS.push(R[hi] + R[hi]); }
      else if (hi > lo) { ALL_HANDS.push(R[hi] + R[lo] + 's'); ALL_HANDS.push(R[hi] + R[lo] + 'o'); }
    }
  }

  function handKey(c1, c2) {
    let r1 = c1 >> 2, r2 = c2 >> 2;
    const suited = (c1 & 3) === (c2 & 3);
    if (r1 < r2) { const t = r1; r1 = r2; r2 = t; }
    if (r1 === r2) return R[r1] + R[r1];
    return R[r1] + R[r2] + (suited ? 's' : 'o');
  }

  function comboCount(key) {
    if (key.length === 2) return 6;
    return key[2] === 's' ? 4 : 12;
  }

  /** 展开成具体的两张牌组合 [[c1,c2],…] */
  function keyToCombos(key) {
    const out = [];
    const r1 = R.indexOf(key[0]), r2 = R.indexOf(key[1]);
    if (key.length === 2) {
      for (let a = 0; a < 4; a++) for (let b = a + 1; b < 4; b++) out.push([r1 * 4 + a, r1 * 4 + b]);
    } else if (key[2] === 's') {
      for (let s = 0; s < 4; s++) out.push([r1 * 4 + s, r2 * 4 + s]);
    } else {
      for (let a = 0; a < 4; a++) for (let b = 0; b < 4; b++) if (a !== b) out.push([r1 * 4 + a, r2 * 4 + b]);
    }
    return out;
  }

  /* ---------- 范围字符串解析 ---------- */
  // 支持: 77+ / 77-99 / A2s+ / KTo+ / A5s-A2s / AKs / 任意项后加 ":0.5"
  function parseRange(str) {
    const range = {};
    if (!str) return range;
    for (let tok of String(str).split(',')) {
      tok = tok.trim();
      if (!tok) continue;
      let freq = 1;
      const colon = tok.indexOf(':');
      if (colon > 0) { freq = parseFloat(tok.slice(colon + 1)); tok = tok.slice(0, colon).trim(); }

      const dash = tok.indexOf('-');
      if (dash > 0) {
        const a = tok.slice(0, dash).trim(), b = tok.slice(dash + 1).trim();
        addSpan(range, a, b, freq);
        continue;
      }
      if (tok.endsWith('+')) { addPlus(range, tok.slice(0, -1), freq); continue; }
      addKey(range, tok, freq);
    }
    return range;
  }

  function addKey(range, key, freq) {
    key = normalizeKey(key);
    if (key) range[key] = Math.max(range[key] || 0, freq);
  }

  function normalizeKey(k) {
    if (!k) return null;
    const r1 = R.indexOf(k[0].toUpperCase());
    const r2 = R.indexOf(k[1].toUpperCase());
    if (r1 < 0 || r2 < 0) return null;
    const hi = Math.max(r1, r2), lo = Math.min(r1, r2);
    if (hi === lo) return R[hi] + R[hi];
    const suffix = (k[2] || 'o').toLowerCase() === 's' ? 's' : 'o';
    return R[hi] + R[lo] + suffix;
  }

  function addPlus(range, key, freq) {
    key = normalizeKey(key);
    if (!key) return;
    if (key.length === 2) {
      const from = R.indexOf(key[0]);
      for (let r = from; r <= 12; r++) addKey(range, R[r] + R[r], freq);
    } else {
      const hi = R.indexOf(key[0]), lo = R.indexOf(key[1]), sfx = key[2];
      for (let r = lo; r < hi; r++) addKey(range, R[hi] + R[r] + sfx, freq);
    }
  }

  function addSpan(range, a, b, freq) {
    a = normalizeKey(a); b = normalizeKey(b);
    if (!a || !b) return;
    if (a.length === 2 && b.length === 2) {
      const x = R.indexOf(a[0]), y = R.indexOf(b[0]);
      for (let r = Math.min(x, y); r <= Math.max(x, y); r++) addKey(range, R[r] + R[r], freq);
    } else if (a.length === 3 && b.length === 3 && a[0] === b[0] && a[2] === b[2]) {
      const x = R.indexOf(a[1]), y = R.indexOf(b[1]);
      for (let r = Math.min(x, y); r <= Math.max(x, y); r++) addKey(range, a[0] + R[r] + a[2], freq);
    }
  }

  /** 范围占全部起手牌的百分比 */
  function rangePercent(range) {
    let n = 0;
    for (const k in range) n += comboCount(k) * range[k];
    return (n / 1326) * 100;
  }

  function mergeRanges(...rs) {
    const out = {};
    for (const r of rs) for (const k in r) out[k] = Math.min(1, (out[k] || 0) + r[k]);
    return out;
  }

  function subtractRange(base, sub) {
    const out = {};
    for (const k in base) {
      const v = base[k] - (sub[k] || 0);
      if (v > 0.001) out[k] = v;
    }
    return out;
  }

  /* ---------- 位置 ---------- */
  // 按人数返回从最早到最晚的位置序列
  function positionsFor(n) {
    switch (n) {
      case 2: return ['SB', 'BB'];
      case 3: return ['BTN', 'SB', 'BB'];
      case 4: return ['CO', 'BTN', 'SB', 'BB'];
      case 5: return ['HJ', 'CO', 'BTN', 'SB', 'BB'];
      case 6: return ['UTG', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
      case 7: return ['UTG', 'UTG1', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
      case 8: return ['UTG', 'UTG1', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
      default: return ['UTG', 'UTG1', 'UTG2', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
    }
  }

  // 位置名带一句白话说明, 免得只看缩写不知道在哪儿
  const POS_LABEL = {
    UTG: '枪口位(第一个说话)',
    UTG1: '枪口后一位',
    UTG2: '枪口后两位',
    MP: '中间位',
    HJ: '腰位(庄位前两个)',
    CO: '关煞位(庄位前一个)',
    BTN: '庄位(最后说话)',
    SB: '小盲位',
    BB: '大盲位',
  };

  /* ---------- 翻前图表 (100bb 深度, 2.2~2.5x 开池) ---------- */
  const RFI = {
    EP:   '55+, A2s-A5s, ATs+, KTs+, QTs+, JTs, T9s, 98s, AJo+, KQo',
    MP:   '44+, A2s-A5s, A9s+, K9s+, Q9s+, J9s+, T8s+, 97s+, 87s, 76s, ATo+, KJo+',
    UTG6: '33+, A2s+, K9s+, Q9s+, J9s+, T8s+, 97s+, 87s, 76s, 65s, ATo+, KJo+, QJo',
    HJ:   '22+, A2s+, K8s+, Q8s+, J8s+, T8s+, 96s+, 86s+, 75s+, 65s, 54s, ATo+, KTo+, QJo',
    CO:   '22+, A2s+, K6s+, Q8s+, J8s+, T7s+, 96s+, 86s+, 75s+, 65s, 54s, ATo+, KTo+, QTo+, JTo',
    BTN:  '22+, A2s+, K2s+, Q4s+, J6s+, T6s+, 95s+, 84s+, 74s+, 63s+, 53s+, 43s, A2o+, K7o+, Q9o+, J9o+, T8o+, 98o, 87o',
    SB:   '22+, A2s+, K2s+, Q2s+, J4s+, T5s+, 95s+, 85s+, 74s+, 64s+, 53s+, 43s, A2o+, K8o+, Q9o+, J9o+, T9o',
    HUSB: '22+, A2s+, K2s+, Q2s+, J2s+, T2s+, 92s+, 82s+, 73s+, 63s+, 53s+, 43s, A2o+, K2o+, Q4o+, J6o+, T6o+, 96o+, 86o+, 75o+, 65o',
  };

  /** 位置 → 开池图表名 (考虑人数) */
  function rfiChartFor(pos, tableSize) {
    if (tableSize === 2) return pos === 'SB' ? 'HUSB' : 'BTN';
    if (pos === 'UTG' || pos === 'UTG1' || pos === 'UTG2') return tableSize >= 8 ? 'EP' : 'UTG6';
    if (pos === 'MP') return 'MP';
    if (pos === 'HJ') return 'HJ';
    if (pos === 'CO') return 'CO';
    if (pos === 'BTN') return 'BTN';
    if (pos === 'SB') return 'SB';
    return 'BB';
  }

  /** 把具体位置归类, 用于查 3bet / 4bet 表 */
  function posClass(pos) {
    if (pos === 'UTG' || pos === 'UTG1' || pos === 'UTG2' || pos === 'MP') return 'EP';
    if (pos === 'HJ') return 'MP';
    if (pos === 'CO') return 'CO';
    if (pos === 'BTN') return 'BTN';
    if (pos === 'SB') return 'SB';
    return 'BB';
  }

  const POS_ORDER = ['UTG', 'UTG1', 'UTG2', 'MP', 'HJ', 'CO', 'BTN', 'SB', 'BB'];
  function isInPosition(hero, villain) {
    // BTN 之后是盲注, 翻后盲注先说话 → 用翻后行动顺序判断
    const order = ['SB', 'BB', 'UTG', 'UTG1', 'UTG2', 'MP', 'HJ', 'CO', 'BTN'];
    return order.indexOf(hero) > order.indexOf(villain);
  }

  /* 面对开池的 3bet 范围: THREEBET[开池者位置类][英雄所处] */
  const THREEBET = {
    EP: {
      IP: 'JJ+, AQs+, AKo, A5s:0.5, A4s:0.35, KJs:0.3',
      SB: 'QQ+, AKs, AKo, AQs:0.6, A5s:0.5, KQs:0.3',
      BB: 'JJ+, AQs+, AKo, A5s:0.6, A4s:0.4, KJs:0.35, QJs:0.2',
    },
    MP: {
      IP: 'TT+, AJs+, AQo+, A5s:0.6, A4s:0.5, A3s:0.35, KTs:0.35, QTs:0.25',
      SB: 'JJ+, AQs+, AKo, AJs:0.4, A5s:0.6, A4s:0.4, KQs:0.4',
      BB: 'TT+, AJs+, AQo+, A5s:0.6, A4s:0.5, A3s:0.4, KJs:0.4, QJs:0.3, 87s:0.25',
    },
    CO: {
      IP: '99+, ATs+, KJs+, AQo+, A5s-A2s:0.6, KTs:0.4, QTs:0.35, J9s:0.3, 76s:0.3',
      SB: 'TT+, AJs+, KQs, AQo+, A5s-A3s:0.6, KJs:0.4, QJs:0.3',
      BB: '99+, ATs+, KJs+, AJo+, KQo:0.5, A5s-A2s:0.6, K9s:0.35, T9s:0.35, 87s:0.35, 76s:0.3',
    },
    BTN: {
      IP: '99+, ATs+, KJs+, AJo+, A5s-A2s:0.7, KTs:0.5, QTs:0.4, J9s:0.4, T9s:0.4',
      SB: '99+, ATs+, KJs+, QJs, AJo+, KQo:0.6, A5s-A2s:0.7, K9s:0.4, T9s:0.4, 98s:0.35, 76s:0.3',
      BB: '88+, A9s+, KTs+, QTs+, JTs, ATo+, KQo, A5s-A2s:0.7, K9s:0.45, T9s:0.45, 98s:0.4, 87s:0.4, 76s:0.35, 65s:0.3',
    },
    SB: {
      BB: '77+, A8s+, K9s+, Q9s+, J9s+, T9s, ATo+, KJo+, A5s-A2s:0.75, 98s:0.5, 87s:0.5, 76s:0.45, 65s:0.4, QTo:0.4, KTo:0.4',
      IP: '77+, A8s+, K9s+, Q9s+, J9s+, T9s, ATo+, KJo+, A5s-A2s:0.75, 98s:0.5, 87s:0.5',
      SB: '99+, AJs+, AQo+',
    },
  };

  /* 面对开池的跟注(平跟)范围 */
  const FLAT = {
    EP: {
      IP: '22-TT, AJs-ATs, KQs, KJs, QJs, JTs, T9s, 98s, AQo, AJo:0.5',
      SB: '77-JJ, AQs, AJs, KQs, QJs:0.5, JTs:0.5',
      BB: '22-TT, A2s-AJs, K8s+, Q9s+, J9s+, T8s+, 97s+, 87s, 76s, 65s, AQo, AJo, KQo, KJo:0.6, QJo:0.5',
    },
    MP: {
      IP: '22-99, ATs-AJs, KTs+, QTs+, JTs, T9s, 98s, 87s, AQo, AJo:0.6, KQo:0.5',
      SB: '77-TT, AQs, AJs, KQs, KJs:0.5, QJs:0.5, JTs:0.5',
      BB: '22-99, A2s-AJs, K7s+, Q8s+, J8s+, T8s+, 96s+, 86s+, 75s+, 65s, 54s, AJo, ATo:0.7, KQo, KJo, QJo:0.7, JTo:0.6',
    },
    CO: {
      IP: '22-88, A9s-AJs, K9s+, Q9s+, J9s+, T9s, 98s, 87s, 76s, AJo, ATo:0.6, KQo, KJo:0.5',
      SB: '55-99, AJs, ATs, KQs, KJs, QJs:0.6, JTs:0.5, AQo:0.5',
      BB: '22-88, A2s-AJs, K5s+, Q7s+, J7s+, T7s+, 96s+, 85s+, 75s+, 64s+, 54s, ATo, A9o:0.6, KJo, KTo:0.8, QTo:0.7, JTo, T9o:0.6',
    },
    BTN: {
      SB: '22-88, A9s-AJs, KTs+, QTs+, JTs, T9s, 98s, ATo:0.6, KQo:0.6',
      BB: '22-88, A2s-AJs, K2s+, Q5s+, J6s+, T6s+, 95s+, 84s+, 74s+, 63s+, 53s+, 43s, A2o-ATo, K8o+, Q9o+, J9o+, T8o+, 98o, 87o, 76o:0.7',
      IP: '22-88, A9s-AJs, KTs+, QTs+, JTs, T9s, 98s, ATo:0.6, KQo:0.6',
    },
    SB: {
      BB: '22-99, A2s-AJs, K2s+, Q4s+, J6s+, T6s+, 95s+, 84s+, 74s+, 63s+, 53s+, A2o-AJo, K5o+, Q8o+, J8o+, T8o+, 97o+, 87o, 76o',
      IP: '22-99, A2s-AJs, K5s+, Q8s+, J8s+, T8s+, 97s+, 87s, 76s, AJo, KQo',
      SB: '22-99, AJs, ATs, KQs',
    },
  };

  /* 面对 3bet 的应对 (英雄是原开池者) */
  const VS_3BET = {
    FOURBET_IP:  'KK+, AKs, AKo:0.7, QQ:0.6, A5s:0.45, A4s:0.35, AQs:0.25',
    FOURBET_OOP: 'KK+, AKs, AKo:0.8, QQ:0.7, A5s:0.5, A4s:0.35, KQs:0.2',
    CALL_IP:     'QQ:0.4, JJ, TT, 99, 88:0.7, 77:0.5, AQs, AJs, ATs:0.7, KQs, KJs:0.7, QJs:0.6, JTs:0.6, T9s:0.5, 98s:0.4, AQo:0.5, AKo:0.3',
    CALL_OOP:    'QQ:0.3, JJ:0.8, TT:0.7, 99:0.6, 88:0.4, AQs, AJs:0.8, KQs:0.8, KJs:0.5, QJs:0.4, JTs:0.4, AQo:0.35, AKo:0.2',
  };

  /* 面对 4bet 的应对 (英雄是 3bet 方)。100bb 深度下 AK/QQ 是全下与跟注的混合 */
  const VS_4BET = {
    SHOVE: 'KK+, QQ:0.6, AKs:0.5, AKo:0.55, A5s:0.25, A4s:0.15',
    CALL:  'QQ:0.4, JJ:0.75, TT:0.35, AKs:0.5, AKo:0.45, AQs:0.55, AJs:0.2, KQs:0.2',
  };

  const CHARTS = { RFI, THREEBET, FLAT, VS_3BET, VS_4BET };

  // 预解析缓存
  const _cache = {};
  function chart(str) {
    if (!_cache[str]) _cache[str] = parseRange(str);
    return _cache[str];
  }

  function rfiRange(pos, tableSize) { return chart(RFI[rfiChartFor(pos, tableSize)] || RFI.EP); }

  function threeBetRange(raiserPos, heroPos) {
    const rc = posClass(raiserPos);
    const table = THREEBET[rc] || THREEBET.BTN;
    const slot = heroPos === 'BB' ? 'BB' : heroPos === 'SB' ? 'SB' : 'IP';
    return chart(table[slot] || table.IP || table.BB);
  }

  function flatRange(raiserPos, heroPos) {
    const rc = posClass(raiserPos);
    const table = FLAT[rc] || FLAT.BTN;
    const slot = heroPos === 'BB' ? 'BB' : heroPos === 'SB' ? 'SB' : 'IP';
    return chart(table[slot] || table.IP || table.BB);
  }

  G.ranges = {
    ALL_HANDS, handKey, comboCount, keyToCombos, parseRange, rangePercent,
    mergeRanges, subtractRange, positionsFor, POS_LABEL, POS_ORDER, posClass,
    isInPosition, rfiChartFor, rfiRange, threeBetRange, flatRange, chart, CHARTS,
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
