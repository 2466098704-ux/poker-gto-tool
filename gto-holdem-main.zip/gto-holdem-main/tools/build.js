/* 把 src 里的模块内联成单文件 dist/index.html */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const ORDER = [
  'src/evaluator.js',
  'src/ranges.js',
  'src/ranking.js',
  'src/equity.js',
  'src/advisor.js',
  'src/glossary.js',
  'src/ai.js',
  'src/ui.js',
];

const js = ORDER.map((f) => `/* ===== ${path.basename(f)} ===== */\n` + read(f)).join('\n');
const css = read('src/styles.css');
// 图标内联成 data URI, 保证整个 app 还是单文件
const icon = 'data:image/png;base64,' +
  fs.readFileSync(path.join(root, 'assets/icon-180.png')).toString('base64');
const html = read('src/app.html')
  .replace('/*@CSS*/', () => css)
  .replace('//@JS', () => js)
  .replaceAll('@ICON', () => icon);

fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/index.html'), html);

/* ---- docs/ : 给 GitHub Pages 用(Pages 只认 / 或 /docs), 多一个 service worker 做离线缓存 ---- */
const swReg = `
<script>
// 只有走 https 时才注册 —— file:// 和普通 http 下 service worker 不可用
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('sw.js').catch(function () { /* 注册不上就算了, 不影响使用 */ });
  });
}
</script>`;
const siteHtml = html
  .replace('<link rel="apple-touch-icon"', '<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon"')
  + swReg;

const site = path.join(root, 'docs');
fs.mkdirSync(site, { recursive: true });
fs.writeFileSync(path.join(site, 'index.html'), siteHtml);
fs.copyFileSync(path.join(root, 'src/sw.js'), path.join(site, 'sw.js'));
fs.copyFileSync(path.join(root, 'src/manifest.webmanifest'), path.join(site, 'manifest.webmanifest'));
for (const s of [180, 512]) {
  fs.copyFileSync(path.join(root, `assets/icon-${s}.png`), path.join(site, `icon-${s}.png`));
}
console.log('docs/            index.html + sw.js + manifest + 2 icons');

const kb = (Buffer.byteLength(html) / 1024).toFixed(0);
console.log(`dist/index.html  ${kb} KB  (JS ${(Buffer.byteLength(js) / 1024).toFixed(0)} KB, CSS ${(Buffer.byteLength(css) / 1024).toFixed(0)} KB)`);
