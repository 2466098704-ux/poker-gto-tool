/* ============================================================
   advisor.js — 决策引擎
   翻前: 直接查 GTO 图表得到混合频率
   翻后: 用范围胜率 + 底池赔率 + 弃牌率算各选项 EV, 再软化成混合策略
   ============================================================ */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});
  const C = G.cards, RG = G.ranges, EQ = G.equity;

  const ITERS = { flop: 24000, turn: 24000, river: 16000, preflop: 20000 };

  /* ---------- 牌面质地 ---------- */
  function texture(board) {
    if (board.length < 3) return null;
    const ranks = board.map((c) => c >> 2);
    const sc = [0, 0, 0, 0];
    for (const c of board) sc[c & 3]++;
    const maxSuit = Math.max(...sc);

    const rc = {};
    for (const r of ranks) rc[r] = (rc[r] || 0) + 1;
    const counts = Object.values(rc);
    const paired = counts.some((v) => v >= 2);
    const trips = counts.some((v) => v >= 3);

    let mask = 0;
    for (const r of ranks) mask |= 1 << r;
    let windows = 0;
    for (let hi = 12; hi >= 4; hi--) {
      let cnt = 0;
      for (let k = 0; k < 5; k++) if (mask & (1 << (hi - k))) cnt++;
      if (cnt >= 3) windows++;
    }
    { // 轮子窗口 A2345
      let cnt = 0;
      for (const r of [12, 0, 1, 2, 3]) if (mask & (1 << r)) cnt++;
      if (cnt >= 3) windows++;
    }

    const suitedness = maxSuit >= 4 ? 0.9 : maxSuit === 3 ? 0.65 : maxSuit === 2 ? 0.25 : 0;
    const straightness = Math.min(1, windows / 3);
    let wet = 0.5 * suitedness + 0.6 * straightness;
    if (paired) wet -= 0.12;
    wet = Math.max(0, Math.min(1, wet));

    const high = Math.max(...ranks);
    const label = wet < 0.3 ? '干燥' : wet < 0.6 ? '中性' : '湿润';
    return {
      wet, paired, trips, maxSuit, high, suitedness, straightness, label,
      highLabel: C.RANK_NAMES_CN[high],
      monotone: maxSuit >= 3,
    };
  }

  /* ---------- 取范围中最强的一部分 ---------- */
  function takeTopOnBoard(combos, board, frac) {
    if (frac >= 0.999) return combos;
    if (frac <= 0.001) return [];
    const scored = combos.map((cb) => ({
      c: cb,
      s: EQ.percentileOnBoard([cb[0], cb[1]], board) * 0.8 +
         EQ.features([cb[0], cb[1]], board).drawStrength * 0.2,
    }));
    scored.sort((a, b) => b.s - a.s);
    const total = EQ.combosWeight(combos);
    const target = total * frac;
    const out = [];
    let acc = 0;
    for (const it of scored) {
      if (acc >= target) break;
      const take = Math.min(it.c[2], target - acc);
      out.push([it.c[0], it.c[1], take]);
      acc += take;
    }
    return out;
  }

  function takeTopPreflop(range, frac) {
    const RK = G.ranking;
    const keys = Object.keys(range).sort(
      (a, b) => (RK.RANK_INDEX[a] ?? 999) - (RK.RANK_INDEX[b] ?? 999)
    );
    let total = 0;
    for (const k in range) total += RG.comboCount(k) * range[k];
    const target = total * frac;
    const out = {};
    let acc = 0;
    for (const k of keys) {
      if (acc >= target) break;
      const n = RG.comboCount(k) * range[k];
      const take = Math.min(n, target - acc);
      out[k] = (take / RG.comboCount(k));
      acc += take;
    }
    return out;
  }

  /* ---------- 混合频率 ---------- */
  function softmax(items, temp) {
    const max = Math.max(...items.map((i) => i.ev));
    let sum = 0;
    for (const it of items) { it._e = Math.exp((it.ev - max) / temp); sum += it._e; }
    for (const it of items) { it.freq = it._e / sum; delete it._e; }
    return items;
  }

  function normalize(items) {
    let s = 0;
    for (const it of items) s += Math.max(0, it.freq);
    if (s <= 0) { items.forEach((i, n) => (i.freq = n === 0 ? 1 : 0)); return items; }
    for (const it of items) it.freq = Math.max(0, it.freq) / s;
    // 2% 以下的频率是模型噪声, 抹掉后重新归一, 免得读数上出现莫名其妙的“弃牌 1%”
    let s2 = 0;
    for (const it of items) { if (it.freq < 0.02) it.freq = 0; s2 += it.freq; }
    if (s2 > 0) for (const it of items) it.freq /= s2;
    return items;
  }

  /* ============================================================
     翻前
     ============================================================ */
  function analyzePreflop(ctx) {
    const key = RG.handKey(ctx.hero[0], ctx.hero[1]);
    const RK = G.ranking;
    const reasons = [];
    const actions = [];
    let villainRange = null, villainLabel = '';
    const bb = 1;
    const pot0 = ctx.potBB;

    const openSize = (pos) => {
      if (ctx.tableSize >= 8 && ['UTG', 'UTG1', 'UTG2', 'MP'].includes(pos)) return 2.5;
      if (pos === 'SB') return 3;
      if (pos === 'BTN' || pos === 'CO') return 2.3;
      return 2.5;
    };

    if (ctx.scenario === 'unopened') {
      const chart = RG.rfiRange(ctx.heroPos, ctx.tableSize);
      const f = chart[key] || 0;
      const size = openSize(ctx.heroPos);
      villainRange = null;
      villainLabel = '尚无人进池';
      reasons.push(
        `你在${RG.POS_LABEL[ctx.heroPos] || ctx.heroPos},这个位置大约有 ${RG.rangePercent(chart).toFixed(1)}% 的起手牌值得第一个加注。` +
        `${key} ${f >= 0.999 ? '在里面 —— 直接加注就行' : f > 0 ? `属于边缘牌,大约 ${(f * 100).toFixed(0)}% 的时候加注、其余时候弃掉` : '不在里面 —— 弃掉'}。`
      );
      if (ctx.heroPos === 'SB') reasons.push('小盲翻牌后要第一个说话,位置最差,所以这里只加注或弃牌,不要只跟一个大盲便宜进池。');
      actions.push({ key: 'raise', label: `加注到 ${size}bb`, freq: f, ev: null, note: f > 0 ? '开池施压' : '' });
      actions.push({ key: 'fold', label: '弃牌', freq: 1 - f, ev: 0, note: '' });
      return finishPreflop(ctx, key, actions, reasons, villainRange, villainLabel, chart);
    }

    if (ctx.scenario === 'vs_limp') {
      const chart = RG.rfiRange(ctx.heroPos, ctx.tableSize);
      const pct = RK.PERCENTILE[key];
      // 面对跛入者用略紧于开池的范围做隔离加注
      const isoFreq = (chart[key] || 0) * (pct < 0.18 ? 1 : 0.7);
      const callFreq = !isoFreq && pct < 0.32 && ctx.heroPos !== 'SB' ? 0.5 : 0;
      const size = 3 + ctx.limpers;
      reasons.push(`有 ${ctx.limpers} 个人只跟不加注,把加注尺度放大到 ${size}bb,好把闲人赶走、单独打其中一个。`);
      reasons.push(`${key} 在全部起手牌里排前 ${(pct * 100).toFixed(0)}%。`);
      actions.push({ key: 'raise', label: `加注到 ${size}bb`, tag: '赶走跛入者', freq: isoFreq, ev: null });
      actions.push({ key: 'call', label: '也只跟一个大盲', freq: callFreq, ev: null });
      actions.push({ key: 'fold', label: '弃牌', freq: Math.max(0, 1 - isoFreq - callFreq), ev: 0 });
      return finishPreflop(ctx, key, actions, reasons, null, '跛入者(偏弱范围)', chart);
    }

    if (ctx.scenario === 'vs_raise') {
      const raiser = ctx.raiserPos;
      const rfi = RG.rfiRange(raiser, ctx.tableSize);
      const tb = RG.threeBetRange(raiser, ctx.heroPos);
      const flat = RG.flatRange(raiser, ctx.heroPos);
      let f3 = tb[key] || 0;
      let fc = flat[key] || 0;
      if (f3 + fc > 1) { const s = f3 + fc; f3 /= s; fc /= s; }
      const ip = RG.isInPosition(ctx.heroPos, raiser);
      const size = +(ctx.openSizeBB * (ip ? 3 : 4)).toFixed(1);

      villainRange = rfi;
      villainLabel = `${RG.POS_LABEL[raiser] || raiser} 开池范围 ${RG.rangePercent(rfi).toFixed(1)}%`;
      reasons.push(`对手在${RG.POS_LABEL[raiser] || raiser}加注,这个位置大约会用 ${RG.rangePercent(rfi).toFixed(1)}% 的起手牌加注。`);
      reasons.push(ip
        ? '翻牌后你在他之后说话(有位置),可以多用跟注,把更多牌留在手里。'
        : '翻牌后你要先说话(没位置),所以要么再加注要么弃牌,少用跟注 —— 位置差的时候跟注很难打。');
      if (ctx.callers > 0) reasons.push(`中间已经有 ${ctx.callers} 个人跟注,底池变大了,你要再加注的话尺度也得跟着放大。`);

      actions.push({ key: 'raise', label: `再加注到 ${size}bb`, tag: '3bet', freq: f3, ev: null });
      actions.push({ key: 'call', label: `跟注 ${ctx.toCallBB}bb`, freq: fc, ev: null });
      actions.push({ key: 'fold', label: '弃牌', freq: Math.max(0, 1 - f3 - fc), ev: 0 });
      return finishPreflop(ctx, key, actions, reasons, rfi, villainLabel, RG.mergeRanges(tb, flat));
    }

    if (ctx.scenario === 'vs_3bet') {
      const ip = RG.isInPosition(ctx.heroPos, ctx.raiserPos);
      const fb = RG.chart(ip ? RG.CHARTS.VS_3BET.FOURBET_IP : RG.CHARTS.VS_3BET.FOURBET_OOP);
      const cl = RG.chart(ip ? RG.CHARTS.VS_3BET.CALL_IP : RG.CHARTS.VS_3BET.CALL_OOP);
      let f4 = fb[key] || 0, fc = cl[key] || 0;
      if (f4 + fc > 1) { const s = f4 + fc; f4 /= s; fc /= s; }
      const size = +(ctx.toCallBB * 2.3).toFixed(1);
      const vr = RG.threeBetRange(ctx.heroPos, ctx.raiserPos);
      reasons.push(`对手在你之后又加了一次(3bet),这种范围一般只有 ${RG.rangePercent(vr).toFixed(1)}% —— 大牌为主,但也掺着 A5s 这类同花 A 在诈唬。`);
      reasons.push(ip ? '你有位置,可以跟得宽一些。' : '你没位置,跟注要更紧,更多地选择再加回去或者直接弃牌。');
      actions.push({ key: 'raise', label: `再加回去到 ${size}bb`, tag: '4bet', freq: f4, ev: null });
      actions.push({ key: 'call', label: `跟注 ${ctx.toCallBB}bb`, freq: fc, ev: null });
      actions.push({ key: 'fold', label: '弃牌', freq: Math.max(0, 1 - f4 - fc), ev: 0 });
      return finishPreflop(ctx, key, actions, reasons, vr, `3bet 范围 ${RG.rangePercent(vr).toFixed(1)}%`, RG.mergeRanges(fb, cl));
    }

    // vs_4bet
    const shove = RG.chart(RG.CHARTS.VS_4BET.SHOVE);
    const call = RG.chart(RG.CHARTS.VS_4BET.CALL);
    const fs = shove[key] || 0, fcc = call[key] || 0;
    const vr4 = RG.chart(RG.CHARTS.VS_3BET.FOURBET_IP);
    reasons.push(`对手第四次加注,这个范围极紧(只有约 ${RG.rangePercent(vr4).toFixed(1)}%),基本就是 KK 以上和 AK,外加零星几手同花 A 诈唬。`);
    reasons.push('100bb 深度下再加就等于全下了,没有留后手的空间 —— 所以只有能跟全下的牌才继续。');
    actions.push({ key: 'raise', label: `全下 ${ctx.effStack}bb`, tag: '5bet', freq: fs, ev: null });
    actions.push({ key: 'call', label: `跟注 ${ctx.toCallBB}bb`, freq: fcc, ev: null });
    actions.push({ key: 'fold', label: '弃牌', freq: Math.max(0, 1 - fs - fcc), ev: 0 });
    return finishPreflop(ctx, key, actions, reasons, vr4, `4bet 范围 ${RG.rangePercent(vr4).toFixed(1)}%`, RG.mergeRanges(shove, call));
  }

  function finishPreflop(ctx, key, actions, reasons, villainRange, villainLabel, heroRange) {
    normalize(actions);
    const RK = G.ranking;
    let eq = null;
    if (villainRange) {
      const combos = EQ.rangeToCombos(villainRange, ctx.hero);
      const list = [];
      for (let i = 0; i < Math.max(1, ctx.villains); i++) list.push(combos);
      eq = EQ.equity(ctx.hero, [], list, ITERS.preflop).equity;
    } else {
      eq = RK.HU_EQUITY[key];
    }

    // EV: 以“现在弃牌 = 0”为基准
    const pot = ctx.potBB, call = ctx.toCallBB;
    const rangePct = villainRange ? RG.rangePercent(villainRange) : 40;
    for (const a of actions) {
      if (a.key === 'fold') a.ev = 0;
      else if (a.key === 'call' && call > 0) a.ev = eq * (pot + call) - call;
      else if (a.key === 'raise') {
        const m = /([\d.]+)bb/.exec(a.label);
        const target = m ? parseFloat(m[1]) : call * 3;
        a.ev = raiseEV(eq, {
          pot, call, target, villainRange, ctx, board: null,
          heroInv: ctx.heroInvested || 0, rangePct,
        });
      } else if (a.key === 'call') a.ev = eq * pot;
    }

    const best = actions.slice().sort((a, b) => b.freq - a.freq)[0];
    return {
      street: 'preflop', handKey: key, actions, reasons, equity: eq,
      villainRange, villainLabel, heroRange,
      eqVsRandom: !villainRange,
      metrics: {
        equity: eq,
        required: call > 0 ? call / (pot + call) : 0,
        potOdds: call > 0 ? (pot / call) : null,
        spr: ctx.effStack / Math.max(pot, 0.1),
        percentile: 1 - (RK.PERCENTILE[key] || 0.5),
      },
      best,
    };
  }

  /**
   * 加注 / 下注的 EV。基准: “现在弃牌 = 0”。
   *   A = 我方还要投入的量        D = 对手还要补的量
   *   对手按 MDF 防守, 但范围越紧越不会弃牌 (looseness 修正)
   *   被跟注时用对手范围里最强的 MDF 部分重算胜率
   */
  function raiseEV(eqBase, o) {
    const { pot, call, target, villainRange, ctx, board } = o;
    const heroInv = o.heroInv || 0;
    const nOpp = Math.max(1, ctx.villains);

    const A = Math.max(0.01, target - heroInv);   // 我方追加投入
    const V = heroInv + call;                     // 对手本街已投入的总额
    const D = Math.max(0.01, target - V);         // 对手需追加
    const mdf = (pot + A) / (pot + A + D);        // 对手最低防守频率

    // 超紧范围(如 4bet 范围)不会真的按 MDF 弃牌, 按范围宽度缩放弃牌率
    const looseness = Math.max(0.22, Math.min(1, (o.rangePct == null ? 30 : o.rangePct) / 30));
    const pFoldEach = Math.max(0, Math.min(0.92, (1 - mdf) * looseness));
    const foldProb = Math.pow(pFoldEach, nOpp);

    let eqCalled = eqBase * 0.82; // 兜底: 被跟注时对手更强
    if (villainRange && board && board.length >= 3) {
      const combos = EQ.rangeToCombos(villainRange, ctx.hero.concat(board));
      const top = takeTopOnBoard(combos, board, Math.min(1, mdf));
      if (top.length) {
        const list = [];
        for (let i = 0; i < nOpp; i++) list.push(top);
        eqCalled = EQ.equity(ctx.hero, board, list, 12000).equity;
      }
    } else if (villainRange && (!board || !board.length)) {
      const top = takeTopPreflop(villainRange, Math.min(1, mdf));
      const combos = EQ.rangeToCombos(top, ctx.hero);
      if (combos.length) {
        const list = [];
        for (let i = 0; i < nOpp; i++) list.push(combos);
        eqCalled = EQ.equity(ctx.hero, [], list, 10000).equity;
      }
    }
    const finalPot = pot + A + D;
    return foldProb * pot + (1 - foldProb) * (eqCalled * finalPot - A);
  }

  /* ============================================================
     翻后
     ============================================================ */
  function villainBaseRange(ctx) {
    switch (ctx.villainRole) {
      case 'opener': return RG.rfiRange(ctx.villainPos, ctx.tableSize);
      case 'caller': return RG.flatRange(ctx.heroPos, ctx.villainPos);
      case '3bettor': return RG.threeBetRange(ctx.heroPos, ctx.villainPos);
      case 'bbdefend': return RG.flatRange(ctx.heroPos, 'BB');
      default: return RG.parseRange('22+, A2s+, K5s+, Q7s+, J8s+, T8s+, 97s+, 87s, 76s, 65s, ATo+, KJo+, QJo');
    }
  }

  function analyzePostflop(ctx) {
    const board = ctx.board;
    const hero = ctx.hero;
    const reasons = [];
    const tex = texture(board);
    const feats = EQ.features(hero, board);
    const pct = EQ.percentileOnBoard(hero, board);

    // 1) 对手范围: 翻前基础范围 → 逐街按其动作收窄
    const base = villainBaseRange(ctx);
    let combos = EQ.rangeToCombos(base, hero.concat(board));
    const streets = ['flop', 'turn', 'river'];
    const curIdx = streets.indexOf(ctx.street);
    for (let i = 0; i < curIdx; i++) {
      const act = ctx.history[streets[i]];
      if (!act || act === 'none') continue;
      const bLen = 3 + i;
      combos = EQ.narrowRange(combos, board.slice(0, bLen), act, 0.66);
    }
    if (ctx.facing === 'bet' || ctx.facing === 'raise') {
      combos = EQ.narrowRange(combos, board, ctx.facing, ctx.toCallBB / Math.max(ctx.potBB, 0.1));
    } else if (ctx.facing === 'check') {
      combos = EQ.narrowRange(combos, board, 'check');
    }
    const villainPct = (EQ.combosWeight(combos) / EQ.combosWeight(EQ.rangeToCombos(base, hero.concat(board)))) *
      RG.rangePercent(base);

    // 2) 胜率
    const list = [];
    for (let i = 0; i < Math.max(1, ctx.villains); i++) list.push(combos);
    const iters = ITERS[ctx.street] || 20000;
    const res = (ctx.street === 'river' && ctx.villains === 1)
      ? EQ.equityExact(hero, board, combos)
      : EQ.equity(hero, board, list, iters);
    const eq = res.equity;

    // 3) 关键数字
    const pot = ctx.potBB, call = ctx.toCallBB;
    const facingBet = (ctx.facing === 'bet' || ctx.facing === 'raise') && call > 0;
    const required = facingBet ? call / (pot + call) : 0;
    const spr = ctx.effStack / Math.max(pot, 0.1);
    const mdf = facingBet ? pot / (pot + call) : null;

    // 4) 下注尺度建议
    const sizeFrac = suggestSize(tex, feats, pct, ctx, spr);
    const betAmt = +(pot * sizeFrac).toFixed(1);

    // 5) 各选项 EV
    const actions = [];
    if (facingBet) {
      actions.push({ key: 'fold', label: '弃牌', ev: 0 });
      actions.push({ key: 'call', label: `跟注 ${call}bb`, ev: eq * (pot + call) - call });
      const heroInv = ctx.heroInvested || 0;
      const raiseTo = +(Math.min(ctx.effStack,
        heroInv + call + (pot + call) * (feats.drawStrength >= 0.85 ? 0.85 : 0.7))).toFixed(1);
      actions.push({
        key: 'raise', label: `加注到 ${raiseTo}bb`,
        ev: raiseEV(eq, {
          pot, call, target: raiseTo, villainRange: rangeFromCombos(combos),
          ctx, board, heroInv, rangePct: villainPct,
        }),
      });
    } else {
      const realize = ctx.inPosition ? 0.9 : 0.78;
      actions.push({ key: 'check', label: '过牌', ev: eq * pot * realize });
      actions.push({
        key: 'bet', label: `下注 ${betAmt}bb (${Math.round(sizeFrac * 100)}% 底池)`,
        ev: raiseEV(eq, {
          pot, call: 0, target: betAmt, villainRange: rangeFromCombos(combos),
          ctx, board, heroInv: 0, rangePct: villainPct,
        }),
      });
    }

    // 6) EV → 混合频率
    const temp = Math.max(0.3 * pot, 0.6);
    softmax(actions, temp);
    applyHeuristics(actions, { eq, required, pct, feats, tex, spr, facingBet, ctx });
    normalize(actions);

    // 7) 说明
    reasons.push(`牌面偏${tex.label}(湿度 ${(tex.wet * 100).toFixed(0)}%)${tex.paired ? ',而且有对子' : ''},最大的一张是 ${tex.highLabel}。` +
      (tex.wet < 0.3 ? '不容易凑出同花顺子,小注就能施压。' : tex.wet >= 0.6 ? '同花顺子的听牌很多,下注要下大一点收保护费。' : ''));
    reasons.push(`你现在是${feats.name}${feats.pairLabel ? '(' + feats.pairLabel + ')' : ''},在这个牌面上比 ${(pct * 100).toFixed(0)}% 的可能牌型都大。`);
    if (feats.outs > 0 && ctx.street !== 'river') {
      const cardsLeft = ctx.street === 'flop' ? 2 : 1;
      const improve = 1 - Math.pow(1 - feats.outs / (52 - 2 - board.length), cardsLeft);
      reasons.push(`还有大约 ${feats.outs} 张牌能让你成牌,一路发到河牌大概有 ${(improve * 100).toFixed(0)}% 的机会追上。`);
    }
    reasons.push(`按他到目前为止的动作推算,他手里大概是这 ${EQ.combosWeight(combos).toFixed(0)} 种牌(占全部起手牌的 ${villainPct.toFixed(1)}%);你对上这一整堆牌的平均胜率是 ${(eq * 100).toFixed(1)}%。`);
    if (facingBet) {
      const gap = ((eq - required) * 100).toFixed(1);
      reasons.push(eq >= required
        ? `跟注需要 ${(required * 100).toFixed(1)}% 胜率,你有 ${(eq * 100).toFixed(1)}%,多出 ${gap} 个百分点。`
        : `跟注需要 ${(required * 100).toFixed(1)}% 胜率,你只有 ${(eq * 100).toFixed(1)}%,差 ${Math.abs(gap)} 个百分点。`);
      reasons.push(`他下这个尺度,你手里至少要有 ${(mdf * 100).toFixed(0)}% 的牌继续打下去;弃得比这还多,他闭着眼睛诈唬都能赚钱。`);
    } else {
      reasons.push(`你剩的筹码是底池的 ${spr.toFixed(1)} 倍,${spr > 8 ? '还很深 —— 别用中等牌把池子打大,留出后面几条街的操作空间' : spr < 3 ? '已经很浅 —— 有强牌就直接把钱堆进去,别磨蹭' : '不深不浅 —— 两条街就能把筹码打光'}。`);
    }

    const best = actions.slice().sort((a, b) => b.freq - a.freq)[0];
    return {
      street: ctx.street, handKey: RG.handKey(hero[0], hero[1]),
      actions, reasons, equity: eq, feats, texture: tex,
      villainRange: rangeFromCombos(combos), villainLabel: `收窄后约 ${villainPct.toFixed(1)}%`,
      metrics: {
        equity: eq, required, potOdds: call > 0 ? pot / call : null,
        spr, mdf, percentile: pct, outs: feats.outs,
        exact: !!res.exact, iters: res.iters,
      },
      best,
    };
  }

  function rangeFromCombos(combos) {
    const out = {};
    for (const [a, b, w] of combos) {
      const k = RG.handKey(a, b);
      out[k] = (out[k] || 0) + w / RG.comboCount(k);
    }
    for (const k in out) out[k] = Math.min(1, out[k]);
    return out;
  }

  function suggestSize(tex, feats, pct, ctx, spr) {
    let f;
    if (tex.wet < 0.3) f = 0.33;
    else if (tex.wet < 0.6) f = 0.6;
    else f = 0.75;
    if (ctx.street === 'river') {
      if (pct > 0.9) f = 0.9;
      else if (pct > 0.75) f = 0.6;
      else f = 0.66;
    }
    if (ctx.villains > 1) f = Math.min(1, f + 0.12);
    if (spr < 2.5) f = Math.min(f, 0.5);
    if (feats.drawStrength >= 0.85 && ctx.street !== 'river') f = Math.max(f, 0.6);
    return f;
  }

  /** 用扑克常识修正纯 EV 得出的频率 */
  function applyHeuristics(actions, s) {
    const get = (k) => actions.find((a) => a.key === k);
    const fold = get('fold'), call = get('call'), raise = get('raise'),
      bet = get('bet'), check = get('check');

    // 明显 +EV 的跟注不该弃牌
    if (fold && call && call.ev > 0.06 * Math.max(1, s.ctx.potBB)) fold.freq *= 0.06;
    // 胜率远低于底池赔率要求 → 大幅提高弃牌
    if (fold && s.facingBet && s.eq < s.required - 0.08 && s.feats.drawStrength < 0.4) {
      fold.freq = Math.max(fold.freq, 0.75);
      if (call) call.freq *= 0.25;
    }
    // 纯空气不该高频加注(留少量诈唬)
    const bluffy = s.pct < 0.45 && s.feats.drawStrength < 0.4;
    if (bluffy) {
      if (raise) raise.freq = Math.min(raise.freq, 0.12);
      if (bet) bet.freq = Math.min(bet.freq, 0.35);
    }
    // 坚果级牌几乎必下注/加注
    if (s.pct > 0.93) {
      if (raise) raise.freq = Math.max(raise.freq, 0.6);
      if (bet) bet.freq = Math.max(bet.freq, 0.8);
      if (fold) fold.freq = 0;
    }
    // 强听牌: 半诈唬有价值
    if (s.feats.drawStrength >= 0.85 && s.ctx.street !== 'river') {
      if (raise) raise.freq = Math.max(raise.freq, 0.3);
      if (bet) bet.freq = Math.max(bet.freq, 0.55);
      if (fold) fold.freq = Math.min(fold.freq, 0.15);
    }
    // 中等牌力: 控池, 少加注
    if (s.pct > 0.55 && s.pct < 0.82 && s.feats.drawStrength < 0.4) {
      if (raise) raise.freq = Math.min(raise.freq, 0.18);
      if (check && bet && s.ctx.street !== 'flop') check.freq = Math.max(check.freq, 0.45);
    }
  }

  /* ---------- 对外入口 ---------- */
  function analyze(ctx) {
    if (ctx.street === 'preflop' || ctx.board.length < 3) return analyzePreflop(ctx);
    return analyzePostflop(ctx);
  }

  G.advisor = { analyze, texture, takeTopOnBoard, takeTopPreflop, rangeFromCombos, villainBaseRange };
})(typeof globalThis !== 'undefined' ? globalThis : this);
