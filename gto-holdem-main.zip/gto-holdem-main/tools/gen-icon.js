/* 生成 180×180 的主屏幕图标 (黑桃), 输出 assets/icon-180.png
   纯手写 PNG 编码, 不依赖任何第三方库 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const SIZES = [180, 512];
const BG = [0x14, 0x18, 0x1e];      // 深墨
const FG = [0xc8, 0xa2, 0x54];      // 黄铜

/* ---- 黑桃形状: 上尖三角 + 两个圆瓣 + 梯形柄 ---- */
function inCircle(x, y, cx, cy, r) {
  const dx = x - cx, dy = y - cy;
  return dx * dx + dy * dy <= r * r;
}
function inTriangle(x, y, ax, ay, bx, by, cx, cy) {
  const s = (bx - ax) * (y - ay) - (by - ay) * (x - ax);
  const t = (cx - bx) * (y - by) - (cy - by) * (x - bx);
  const u = (ax - cx) * (y - cy) - (ay - cy) * (x - cx);
  return (s >= 0 && t >= 0 && u >= 0) || (s <= 0 && t <= 0 && u <= 0);
}
function inSpade(x, y) {
  // 上半部的尖三角
  if (inTriangle(x, y, 0.50, 0.13, 0.13, 0.60, 0.87, 0.60)) return true;
  // 左右两个圆瓣
  if (inCircle(x, y, 0.31, 0.58, 0.20)) return true;
  if (inCircle(x, y, 0.69, 0.58, 0.20)) return true;
  // 底部的柄: 上窄下宽的梯形
  if (y >= 0.60 && y <= 0.87) {
    const w = 0.030 + (y - 0.60) * 0.44;
    if (Math.abs(x - 0.5) <= w) return true;
  }
  return false;
}

/* ---- 逐像素填色, 4×4 超采样做抗锯齿 ---- */
function render(SIZE) {
  const raw = Buffer.alloc(SIZE * (SIZE * 4 + 1));
  let p = 0;
  for (let py = 0; py < SIZE; py++) {
    raw[p++] = 0; // 每行的 filter 字节
    for (let px = 0; px < SIZE; px++) {
      let hits = 0;
      for (let sy = 0; sy < 4; sy++) {
        for (let sx = 0; sx < 4; sx++) {
          const x = (px + (sx + 0.5) / 4) / SIZE;
          const y = (py + (sy + 0.5) / 4) / SIZE;
          if (inSpade(x, y)) hits++;
        }
      }
      const a = hits / 16;
      raw[p++] = Math.round(BG[0] + (FG[0] - BG[0]) * a);
      raw[p++] = Math.round(BG[1] + (FG[1] - BG[1]) * a);
      raw[p++] = Math.round(BG[2] + (FG[2] - BG[2]) * a);
      raw[p++] = 255;
    }
  }
  return raw;
}

/* ---- PNG 封装 ---- */
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();
function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
}

for (const SIZE of SIZES) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(SIZE, 0);
  ihdr.writeUInt32BE(SIZE, 4);
  ihdr[8] = 8;   // 位深
  ihdr[9] = 6;   // RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(render(SIZE), { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
  const out = path.join(__dirname, `../assets/icon-${SIZE}.png`);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, png);
  console.log(`assets/icon-${SIZE}.png  ${SIZE}×${SIZE}  ${(png.length / 1024).toFixed(1)} KB`);
}
