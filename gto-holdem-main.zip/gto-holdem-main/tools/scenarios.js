/* 决策引擎场景验证 */
globalThis.GTO = {};
require('../src/evaluator.js');
require('../src/ranges.js');
require('../src/ranking.js');
require('../src/equity.js');
require('../src/advisor.js');
const { cards: C, advisor: AD } = globalThis.GTO;

function h(s) { return s.trim().split(/\s+/).map(C.cardFromStr); }
let fails = 0;

function run(title, ctx, expect) {
  const base = {
    tableSize: 6, heroPos: 'BTN', board: [], street: 'preflop', effStack: 100,
    potBB: 1.5, toCallBB: 0, scenario: 'unopened', raiserPos: 'CO', openSizeBB: 2.5,
    callers: 0, limpers: 0, villains: 1, villainRole: 'opener', villainPos: 'CO',
    history: {}, facing: 'none', inPosition: true, heroInvested: 0,
  };
  const c = Object.assign(base, ctx);
  const r = AD.analyze(c);
  const line = r.actions
    .slice().sort((a, b) => b.freq - a.freq)
    .map((a) => `${a.label} ${(a.freq * 100).toFixed(0)}%${a.ev != null ? ` [EV ${a.ev >= 0 ? '+' : ''}${a.ev.toFixed(2)}bb]` : ''}`)
    .join('   ');
  const ok = expect(r);
  if (!ok) fails++;
  console.log(`${ok ? '  ok  ' : '  FAIL'} ${title}`);
  console.log(`        胜率 ${(r.equity * 100).toFixed(1)}%  →  ${line}`);
  if (r.metrics.required) console.log(`        需要胜率 ${(r.metrics.required * 100).toFixed(1)}%  MDF ${r.metrics.mdf ? (r.metrics.mdf * 100).toFixed(0) + '%' : '-'}  SPR ${r.metrics.spr.toFixed(1)}`);
  console.log('        ' + r.reasons[0]);
  return r;
}
const top = (r) => r.actions.slice().sort((a, b) => b.freq - a.freq)[0].key;
const freqOf = (r, k) => (r.actions.find((a) => a.key === k) || {}).freq || 0;

console.log('\n════ 翻前 ════\n');

run('6人桌 BTN 拿 AKs, 前面全弃', { hero: h('As Ks'), heroPos: 'BTN' },
  (r) => top(r) === 'raise' && freqOf(r, 'raise') > 0.95);

run('6人桌 UTG 拿 72o, 前面全弃', { hero: h('7s 2h'), heroPos: 'UTG' },
  (r) => top(r) === 'fold' && freqOf(r, 'fold') > 0.95);

run('6人桌 UTG 拿 AJo, 前面全弃', { hero: h('As Jh'), heroPos: 'UTG' },
  (r) => top(r) === 'raise');

run('9人桌 UTG 拿 K9s, 前面全弃', { hero: h('Ks 9s'), heroPos: 'UTG', tableSize: 9 },
  (r) => top(r) === 'fold');

run('9人桌 BTN 拿 K9s, 前面全弃', { hero: h('Ks 9s'), heroPos: 'BTN', tableSize: 9 },
  (r) => top(r) === 'raise');

run('BB 面对 BTN 开池 2.5bb, 拿 AQs', {
  hero: h('As Qs'), heroPos: 'BB', scenario: 'vs_raise', raiserPos: 'BTN',
  openSizeBB: 2.5, potBB: 4, toCallBB: 1.5, inPosition: false,
}, (r) => top(r) === 'raise');

run('BB 面对 BTN 开池 2.5bb, 拿 J8s', {
  hero: h('Js 8s'), heroPos: 'BB', scenario: 'vs_raise', raiserPos: 'BTN',
  openSizeBB: 2.5, potBB: 4, toCallBB: 1.5, inPosition: false,
}, (r) => top(r) === 'call');

run('BB 面对 UTG 开池, 拿 K9o', {
  hero: h('Ks 9h'), heroPos: 'BB', scenario: 'vs_raise', raiserPos: 'UTG',
  openSizeBB: 2.5, potBB: 4, toCallBB: 1.5, inPosition: false,
}, (r) => top(r) === 'fold');

run('CO 开池后面对 BTN 3bet, 拿 AKo', {
  hero: h('As Kh'), heroPos: 'CO', scenario: 'vs_3bet', raiserPos: 'BTN',
  potBB: 13, toCallBB: 7.5, inPosition: false, heroInvested: 2.5,
}, (r) => top(r) === 'raise');

run('CO 开池后面对 BTN 3bet, 拿 A9s', {
  hero: h('As 9s'), heroPos: 'CO', scenario: 'vs_3bet', raiserPos: 'BTN',
  potBB: 13, toCallBB: 7.5, inPosition: false, heroInvested: 2.5,
}, (r) => top(r) === 'fold');

run('3bet 后面对 4bet, 拿 AKs (应为全下/跟注混合, 不弃牌)', {
  hero: h('As Ks'), heroPos: 'BTN', scenario: 'vs_4bet', raiserPos: 'CO',
  potBB: 35, toCallBB: 16, inPosition: true, heroInvested: 10.5,
}, (r) => freqOf(r, 'fold') < 0.05);

run('3bet 后面对 4bet, 拿 A5s', {
  hero: h('As 5s'), heroPos: 'BTN', scenario: 'vs_4bet', raiserPos: 'CO',
  potBB: 35, toCallBB: 16, inPosition: true, heroInvested: 10.5,
}, (r) => top(r) === 'fold');

console.log('\n════ 翻牌 ════\n');

run('顶对顶踢 A72彩虹, 对手下注半池', {
  hero: h('As Kd'), board: h('Ah 7d 2c'), street: 'flop', heroPos: 'BTN',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 6, toCallBB: 3,
  facing: 'bet', effStack: 97, inPosition: true,
}, (r) => top(r) === 'call' || top(r) === 'raise');

run('坚果同花听牌 面对 2/3 池下注', {
  hero: h('As Ks'), board: h('Qs 7s 2h'), street: 'flop', heroPos: 'BTN',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 6, toCallBB: 4,
  facing: 'bet', effStack: 97, inPosition: true,
}, (r) => top(r) !== 'fold');

run('空气牌 面对满池下注', {
  hero: h('7h 3d'), board: h('As Kd Qc'), street: 'flop', heroPos: 'BB',
  villainRole: 'opener', villainPos: 'CO', potBB: 6, toCallBB: 6,
  facing: 'bet', effStack: 97, inPosition: false,
}, (r) => top(r) === 'fold');

run('底三条(set) 无人下注, 我先说话', {
  hero: h('7s 7h'), board: h('Ah 7d 2c'), street: 'flop', heroPos: 'BB',
  villainRole: 'opener', villainPos: 'CO', potBB: 6, toCallBB: 0,
  facing: 'none', effStack: 97, inPosition: false,
}, (r) => top(r) === 'bet');

run('中对 无人下注, 有位置', {
  hero: h('9s 9h'), board: h('Ah 7d 2c'), street: 'flop', heroPos: 'BTN',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 6, toCallBB: 0,
  facing: 'check', effStack: 97, inPosition: true,
}, (r) => true);

console.log('\n════ 转牌 / 河牌 ════\n');

run('河牌成同花, 对手下注 3/4 池', {
  hero: h('As 5s'), board: h('Ks 9s 2h 7d 3s'), street: 'river', heroPos: 'BTN',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 20, toCallBB: 15,
  facing: 'bet', effStack: 80, inPosition: true, history: { flop: 'call', turn: 'call' },
}, (r) => top(r) !== 'fold');

run('河牌错过听牌, 面对大注', {
  hero: h('Ts 9s'), board: h('Ks 7h 2c 4d Ah'), street: 'river', heroPos: 'BTN',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 20, toCallBB: 16,
  facing: 'bet', effStack: 80, inPosition: true, history: { flop: 'call', turn: 'call' },
}, (r) => top(r) === 'fold');

run('转牌 超对 面对加注', {
  hero: h('Qs Qh'), board: h('9s 7d 2c 5h'), street: 'turn', heroPos: 'CO',
  villainRole: 'bbdefend', villainPos: 'BB', potBB: 18, toCallBB: 14,
  facing: 'raise', effStack: 70, inPosition: true, history: { flop: 'call' },
}, (r) => true);

console.log('\n' + (fails ? `❌ ${fails} 项与预期不符` : '✅ 全部场景符合预期'));
