/* ============================================================
   ai.js — 接大模型做「AI 教练」
   分工: 数字全部由本地求解器算好, 模型只负责解释和实战调整建议
   ============================================================ */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});

  /* ---------- 服务商 ---------- */
  const PROVIDERS = {
    deepseek: {
      name: 'DeepSeek',
      baseUrl: 'https://api.deepseek.com',
      keyUrl: 'platform.deepseek.com',
      keyHint: 'sk- 开头',
      models: [
        { id: 'deepseek-chat', label: 'deepseek-chat', note: 'V3,快而便宜,日常够用' },
        { id: 'deepseek-reasoner', label: 'deepseek-reasoner', note: 'R1,先推理再回答,复杂牌局更准' },
      ],
    },
    openai: {
      name: 'OpenAI',
      baseUrl: 'https://api.openai.com/v1',
      keyUrl: 'platform.openai.com',
      keyHint: 'sk- 开头',
      models: [
        { id: 'gpt-4o-mini', label: 'gpt-4o-mini', note: '便宜' },
        { id: 'gpt-4o', label: 'gpt-4o', note: '更强' },
      ],
    },
    moonshot: {
      name: 'Kimi 月之暗面',
      baseUrl: 'https://api.moonshot.cn/v1',
      keyUrl: 'platform.moonshot.cn',
      keyHint: 'sk- 开头',
      models: [
        { id: 'moonshot-v1-8k', label: 'moonshot-v1-8k', note: '标准' },
        { id: 'moonshot-v1-32k', label: 'moonshot-v1-32k', note: '长上下文' },
      ],
    },
    custom: {
      name: '自定义(任何 OpenAI 兼容接口)',
      baseUrl: '',
      keyUrl: '',
      keyHint: '按你的服务商而定',
      models: [],
      custom: true,
    },
  };

  /* ---------- 把本地算出来的东西整理成给模型看的材料 ---------- */
  function buildContext(res, snap) {
    const C = G.cards, RG = G.ranges;
    const card = (c) => C.RANK_NAMES_CN[c >> 2] + C.SUIT_SYMBOLS[c & 3];
    const L = [];

    L.push(`【牌桌】${snap.tableSize} 人桌,我在 ${snap.heroPos}(${RG.POS_LABEL[snap.heroPos] || ''}),有效筹码 ${snap.effStack}bb`);
    L.push(`【我的手牌】${snap.hero.map(card).join(' ')} = ${res.handKey}`);
    if (snap.board.length) {
      const streetCN = { flop: '翻牌圈', turn: '转牌圈', river: '河牌圈' }[res.street] || res.street;
      L.push(`【公共牌】${snap.board.map(card).join(' ')}(${streetCN})`);
      if (res.texture) {
        L.push(`【牌面质地】${res.texture.label},湿度 ${(res.texture.wet * 100).toFixed(0)}%${res.texture.paired ? ',成对' : ''}`);
      }
      if (res.feats) {
        L.push(`【我的成牌】${res.feats.name}${res.feats.pairLabel ? '(' + res.feats.pairLabel + ')' : ''}` +
          `${res.feats.flushDraw ? ',带同花听牌' : ''}${res.feats.oesd ? ',带两头顺听牌' : res.feats.gutshot ? ',带卡顺听牌' : ''}`);
      }
    } else {
      L.push('【阶段】翻前');
      L.push(`【局面】${snap.scenarioText}`);
    }

    L.push(`【底池】${snap.potBB}bb${snap.toCallBB > 0 ? `,我需要跟注 ${snap.toCallBB}bb` : ',目前无人下注'}`);
    if (snap.villainDesc) L.push(`【对手】${snap.villainDesc}`);

    const m = res.metrics;
    const num = [];
    num.push(`我的胜率 ${(m.equity * 100).toFixed(1)}%`);
    if (m.required > 0) num.push(`跟注所需胜率 ${(m.required * 100).toFixed(1)}%`);
    if (m.potOdds) num.push(`底池赔率 ${m.potOdds.toFixed(1)}:1`);
    if (m.mdf != null) num.push(`对手要求的最低防守频率 ${(m.mdf * 100).toFixed(0)}%`);
    num.push(`SPR ${m.spr.toFixed(1)}`);
    if (m.outs) num.push(`补牌 ${m.outs} 张`);
    L.push('【求解器算出的数字】' + num.join(','));

    L.push('【求解器给的策略】' + res.actions
      .slice().sort((a, b) => b.freq - a.freq)
      .map((a) => `${a.label} ${(a.freq * 100).toFixed(0)}%${a.ev != null ? `(单街 EV ${a.ev >= 0 ? '+' : ''}${a.ev.toFixed(2)}bb)` : ''}`)
      .join(' / '));

    if (res.villainRange) {
      const top = Object.entries(res.villainRange)
        .filter(([, v]) => v > 0.5).map(([k]) => k).slice(0, 40);
      if (top.length) L.push(`【对手可能的牌】${top.join(' ')}${top.length >= 40 ? ' …' : ''}`);
    }
    L.push('【求解器的推理】' + res.reasons.join(' '));
    return L.join('\n');
  }

  const SYSTEM_PROMPT = `你是一位德州扑克教练,正在带一个刚入门的学生复盘。

规则:
1. 用户消息里【】标注的所有数字,都来自一个已经跑完的本地求解器(7 张牌评估器 + 几万次蒙特卡洛模拟 + GTO 翻前图表)。这些数字是准的,直接引用,不要自己重算、不要质疑、更不要编新的数字。
2. 你的价值在于解释「为什么」,以及求解器给不了的东西:对手类型的针对性调整、下一条街的计划、常见的思维误区。
3. 用中文,大白话。行话第一次出现时用括号解释一下。
4. 简短。默认 3~5 句话说清楚,除非用户明确要求展开。不要用小标题堆砌,像人说话一样。
5. 如果用户问的东西超出当前牌局信息范围,直接说需要什么信息,别瞎猜。`;

  /* ---------- 请求 ---------- */
  function endpointOf(cfg) {
    const base = (cfg.provider === 'custom' ? cfg.baseUrl : PROVIDERS[cfg.provider].baseUrl) || '';
    return base.replace(/\/+$/, '') + '/chat/completions';
  }

  /**
   * 流式对话。onDelta(text, kind) 里 kind 为 'reasoning' 时是 R1 的思考过程。
   */
  async function chat(cfg, messages, onDelta, signal) {
    const url = endpointOf(cfg);
    let resp;
    try {
      resp = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + cfg.apiKey,
        },
        body: JSON.stringify({
          model: cfg.model,
          messages,
          stream: true,
          temperature: cfg.temperature != null ? cfg.temperature : 0.6,
        }),
        signal,
      });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      const err = new Error('BLOCKED');
      err.kind = 'blocked';
      err.detail = e.message;
      throw err;
    }

    if (!resp.ok) {
      let body = '';
      try { body = await resp.text(); } catch (e) { /* 读不到就算了 */ }
      let msg = body;
      try { msg = JSON.parse(body).error.message || body; } catch (e) { /* 非 JSON */ }
      const err = new Error(msg || ('HTTP ' + resp.status));
      err.kind = 'http';
      err.status = resp.status;
      throw err;
    }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '', full = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        const s = line.trim();
        if (!s.startsWith('data:')) continue;
        const payload = s.slice(5).trim();
        if (payload === '[DONE]') continue;
        let j;
        try { j = JSON.parse(payload); } catch (e) { continue; }
        const d = j.choices && j.choices[0] && j.choices[0].delta;
        if (!d) continue;
        if (d.reasoning_content) onDelta(d.reasoning_content, 'reasoning');
        if (d.content) { full += d.content; onDelta(d.content, 'content'); }
      }
    }
    return full;
  }

  /** 用一次极小的请求验证 key 和模型名是否可用 */
  async function testKey(cfg) {
    const resp = await fetch(endpointOf(cfg), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.apiKey },
      body: JSON.stringify({ model: cfg.model, messages: [{ role: 'user', content: 'hi' }], max_tokens: 1 }),
    });
    if (resp.ok) return { ok: true };
    let msg = '';
    try { msg = JSON.parse(await resp.text()).error.message; } catch (e) { msg = 'HTTP ' + resp.status; }
    return { ok: false, status: resp.status, message: msg };
  }

  /** 把各种失败翻译成人能看懂的话 */
  function explainError(e) {
    if (e.kind === 'blocked') {
      return '连不上模型接口。如果你现在打开的是 claude.ai 上的分享页,那是这个页面的安全策略禁止对外请求 —— ' +
        'AI 功能需要用本地那个 HTML 文件打开,或者把它传到你自己的网址上。也可能只是网络不通。';
    }
    if (e.kind === 'http') {
      if (e.status === 401) return 'API Key 不对,或者已经失效。到设置里重新填一个。';
      if (e.status === 402) return '账户余额不足,去服务商那边充值。';
      if (e.status === 429) return '请求太频繁,或者超出了配额,等一会儿再试。';
      if (e.status === 400) return '请求被拒绝,多半是模型名字写错了:' + (e.message || '');
      if (e.status === 404) return '接口地址不对,检查一下 Base URL。';
      return '接口报错(' + e.status + '):' + (e.message || '');
    }
    return e.message || '未知错误';
  }

  G.ai = { PROVIDERS, buildContext, chat, testKey, explainError, SYSTEM_PROMPT };
})(typeof globalThis !== 'undefined' ? globalThis : this);
