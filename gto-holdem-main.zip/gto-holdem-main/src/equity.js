/* ============================================================
   equity.js — 胜率计算 (蒙特卡洛 / 河牌精确枚举) + 牌力特征
   ============================================================ */
(function (root) {
  'use strict';
  const G = (root.GTO = root.GTO || {});
  const C = G.cards, RG = G.ranges;

  /* ---------- 把范围展开成 [c1,c2,weight] 并排除已知牌 ---------- */
  function rangeToCombos(range, dead) {
    const blocked = new Uint8Array(52);
    for (const c of dead || []) if (c >= 0) blocked[c] = 1;
    const out = [];
    for (const key in range) {
      const w = range[key];
      if (w <= 0.0001) continue;
      for (const [a, b] of RG.keyToCombos(key)) {
        if (blocked[a] || blocked[b]) continue;
        out.push([a, b, w]);
      }
    }
    return out;
  }

  function fullRangeCombos(dead) {
    const blocked = new Uint8Array(52);
    for (const c of dead || []) if (c >= 0) blocked[c] = 1;
    const out = [];
    for (let a = 0; a < 52; a++) {
      if (blocked[a]) continue;
      for (let b = a + 1; b < 52; b++) {
        if (blocked[b]) continue;
        out.push([a, b, 1]);
      }
    }
    return out;
  }

  function combosWeight(combos) {
    let t = 0;
    for (const c of combos) t += c[2];
    return t;
  }

  /* ---------- 牌力特征 ---------- */
  const _tmp7 = new Array(7);

  function evalWith(hole, board) {
    const n = board.length;
    for (let i = 0; i < n; i++) _tmp7[i] = board[i];
    _tmp7[n] = hole[0]; _tmp7[n + 1] = hole[1];
    _tmp7.length = n + 2;
    return C.evaluate(_tmp7);
  }

  /** 数一下还差哪些点数能凑成顺子 */
  function straightOutRanks(cards) {
    let mask = 0;
    for (const c of cards) mask |= 1 << (c >> 2);
    if (C.STRAIGHT[mask] >= 0) return 0;
    let n = 0;
    for (let r = 0; r < 13; r++) {
      if (mask & (1 << r)) continue;
      if (C.STRAIGHT[mask | (1 << r)] >= 0) n++;
    }
    return n;
  }

  /**
   * 手牌在当前牌面上的特征。
   * 返回 made 牌型、听牌、与公共牌的关系。
   */
  function features(hole, board) {
    const all = hole.concat(board);
    const score = C.evaluate(all);
    const cat = score >>> 20;

    // 同花听牌
    const suits = [0, 0, 0, 0];
    for (const c of all) suits[c & 3]++;
    let flushDraw = false, backdoorFlush = false, flushSuit = -1;
    for (let s = 0; s < 4; s++) {
      if (suits[s] === 4) { flushDraw = true; flushSuit = s; }
      else if (suits[s] === 3 && board.length === 3) backdoorFlush = true;
    }
    const holeInFlush = flushDraw && ((hole[0] & 3) === flushSuit || (hole[1] & 3) === flushSuit);

    // 顺子听牌
    const sOuts = board.length >= 3 ? straightOutRanks(all) : 0;
    const oesd = sOuts >= 2, gutshot = sOuts === 1;

    // 与牌面的关系
    const boardRanks = board.map((c) => c >> 2).sort((a, b) => b - a);
    const h1 = hole[0] >> 2, h2 = hole[1] >> 2;
    const hiHole = Math.max(h1, h2), loHole = Math.min(h1, h2);
    const topBoard = boardRanks.length ? boardRanks[0] : -1;
    const pocketPair = h1 === h2;

    let pairLabel = '';
    if (board.length >= 3) {
      if (pocketPair && h1 > topBoard) pairLabel = '超对';
      else if (cat === 1) {
        const pr = (score >> 16) & 15;
        if (boardRanks.includes(pr)) {
          const idx = boardRanks.indexOf(pr);
          pairLabel = idx === 0 ? '顶对' : idx === 1 ? '中对' : '底对';
        } else pairLabel = '口袋对(低于牌面)';
      }
    }

    const overcards = board.length >= 3
      ? (hiHole > topBoard ? 1 : 0) + (loHole > topBoard ? 1 : 0) : 0;

    let drawStrength = 0;
    if (flushDraw && holeInFlush) drawStrength = Math.max(drawStrength, 1.0);
    if (oesd) drawStrength = Math.max(drawStrength, 0.85);
    if (gutshot) drawStrength = Math.max(drawStrength, 0.4);
    if (backdoorFlush) drawStrength = Math.max(drawStrength, 0.15);

    let outs = 0;
    if (flushDraw && holeInFlush) outs += 9;
    if (oesd) outs += 8 - (flushDraw && holeInFlush ? 2 : 0);
    else if (gutshot) outs += 4 - (flushDraw && holeInFlush ? 1 : 0);
    if (cat === 0 && overcards === 2) outs += 6;

    return {
      score, cat, name: C.describeScore(score),
      flushDraw: flushDraw && holeInFlush, backdoorFlush, oesd, gutshot,
      drawStrength, outs, pairLabel, overcards, pocketPair,
    };
  }

  /* ---------- 牌面上的相对强度 (百分位) ---------- */
  // 只按公共牌缓存 — 千万别把手牌并进 key, 否则每个组合都要重建一次全表
  const _boardCache = new Map();
  function boardScores(board) {
    const key = board.slice().sort((a, b) => a - b).join(',');
    if (_boardCache.has(key)) return _boardCache.get(key);
    const blocked = new Uint8Array(52);
    for (const c of board) blocked[c] = 1;
    const list = [];
    for (let a = 0; a < 52; a++) {
      if (blocked[a]) continue;
      for (let b = a + 1; b < 52; b++) {
        if (blocked[b]) continue;
        list.push(evalWith([a, b], board));
      }
    }
    list.sort((x, y) => x - y);
    const res = { sorted: list };
    if (_boardCache.size > 24) _boardCache.clear();
    _boardCache.set(key, res);
    return res;
  }

  /** 该手牌强于牌面上多少比例的组合 (0~1) */
  function percentileOnBoard(hole, board) {
    if (board.length < 3) return 0.5;
    const { sorted } = boardScores(board);
    const s = evalWith(hole, board);
    let lo = 0, hi = sorted.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (sorted[m] < s) lo = m + 1; else hi = m; }
    return sorted.length ? lo / sorted.length : 0.5;
  }

  /* ---------- 范围收窄 ---------- */
  /**
   * 依据对手在本条街的动作收窄其范围。
   * mode: 'bet' | 'raise' | 'call' | 'check'
   * aggression: 下注尺度 (占底池比例), 越大范围越极化
   */
  function narrowRange(combos, board, mode, aggression) {
    if (!combos.length || board.length < 3) return combos;

    const scored = combos.map((cb) => {
      const f = features([cb[0], cb[1]], board);
      const pct = percentileOnBoard([cb[0], cb[1]], board);
      const s = pct * 0.78 + f.drawStrength * 0.22;
      return { c: cb, s, pct, draw: f.drawStrength };
    });
    scored.sort((a, b) => b.s - a.s);

    const total = combosWeight(combos);
    const out = [];
    const push = (item, mult) => {
      if (mult > 0.02) out.push([item.c[0], item.c[1], item.c[2] * mult]);
    };

    if (mode === 'check') {
      // 过牌: 去掉大部分最强牌, 但保留少量慢打
      let acc = 0;
      for (const it of scored) {
        acc += it.c[2];
        const p = acc / total;
        push(it, p < 0.08 ? 0.3 : p < 0.16 ? 0.75 : 1);
      }
      return out;
    }

    if (mode === 'call') {
      // 跟注: 保留中上段 + 听牌, 砍掉纯空气与部分最强牌(会加注)
      const keep = 0.60;
      let acc = 0;
      for (const it of scored) {
        acc += it.c[2];
        const p = acc / total;
        let mult;
        if (p < 0.06) mult = 0.35;              // 最强牌更多选择加注
        else if (p < keep) mult = 1;
        else mult = it.draw >= 0.4 ? 0.55 : 0.06; // 听牌仍会跟
        push(it, mult);
      }
      return out;
    }

    // bet / raise: 极化 — 强牌 + 听牌诈唬
    const big = Math.min(1.2, Math.max(0.25, aggression || 0.66));
    const valueTop = mode === 'raise' ? 0.14 : (big > 0.8 ? 0.20 : 0.34);
    const bluffFrac = mode === 'raise' ? 0.10 : 0.16;
    let acc = 0;
    for (const it of scored) {
      acc += it.c[2];
      const p = acc / total;
      let mult = 0;
      if (p < valueTop) mult = 1;
      else if (it.draw >= 0.4) mult = 0.5;
      else if (p > 1 - bluffFrac) mult = 0.28;
      else mult = 0.06;
      push(it, mult);
    }
    return out.length ? out : combos;
  }

  /* ---------- 蒙特卡洛 ---------- */
  function equity(hero, board, oppCombosList, iters) {
    const nOpp = oppCombosList.length;
    if (!nOpp) return { equity: 1, win: 1, tie: 0, lose: 0, iters: 0 };

    // 累积权重, 便于按权重抽样
    const cum = oppCombosList.map((combos) => {
      const arr = new Float64Array(combos.length);
      let t = 0;
      for (let i = 0; i < combos.length; i++) { t += combos[i][2]; arr[i] = t; }
      return { arr, total: t, combos };
    });
    for (const c of cum) if (c.total <= 0) return { equity: 0.5, win: 0, tie: 0, lose: 0, iters: 0 };

    const pick = (c) => {
      const r = Math.random() * c.total;
      let lo = 0, hi = c.arr.length - 1;
      while (lo < hi) { const m = (lo + hi) >> 1; if (c.arr[m] < r) lo = m + 1; else hi = m; }
      return c.combos[lo];
    };

    const used = new Uint8Array(52);
    const deck = new Int32Array(52);
    const need = 5 - board.length;
    const full = new Array(7);
    const oppHole = new Array(nOpp);

    let win = 0, tie = 0, lose = 0, done = 0;

    for (let it = 0; it < iters; it++) {
      used.fill(0);
      used[hero[0]] = 1; used[hero[1]] = 1;
      for (const b of board) used[b] = 1;

      let ok = true;
      for (let o = 0; o < nOpp; o++) {
        let got = null;
        for (let tries = 0; tries < 24; tries++) {
          const cb = pick(cum[o]);
          if (!used[cb[0]] && !used[cb[1]]) { got = cb; break; }
        }
        if (!got) { ok = false; break; }
        used[got[0]] = 1; used[got[1]] = 1;
        oppHole[o] = got;
      }
      if (!ok) continue;

      let dn = 0;
      for (let c = 0; c < 52; c++) if (!used[c]) deck[dn++] = c;
      // 只洗前 need 张
      for (let i = 0; i < need; i++) {
        const j = i + ((Math.random() * (dn - i)) | 0);
        const t = deck[i]; deck[i] = deck[j]; deck[j] = t;
      }

      for (let i = 0; i < board.length; i++) full[i] = board[i];
      for (let i = 0; i < need; i++) full[board.length + i] = deck[i];
      full.length = 5;

      full.push(hero[0], hero[1]);
      const hs = C.evaluate(full);
      full.length = 5;

      let best = -1, ties = 0;
      for (let o = 0; o < nOpp; o++) {
        full.push(oppHole[o][0], oppHole[o][1]);
        const s = C.evaluate(full);
        full.length = 5;
        if (s > best) best = s;
      }
      if (hs > best) win++;
      else if (hs === best) {
        // 统计平分人数
        ties = 1;
        for (let o = 0; o < nOpp; o++) {
          full.push(oppHole[o][0], oppHole[o][1]);
          if (C.evaluate(full) === hs) ties++;
          full.length = 5;
        }
        tie += 1 / ties;
      } else lose++;
      done++;
    }

    if (!done) return { equity: 0.5, win: 0, tie: 0, lose: 0, iters: 0 };
    return { equity: (win + tie) / done, win: win / done, tie: tie / done, lose: lose / done, iters: done };
  }

  /** 河牌单挑时可精确枚举 */
  function equityExact(hero, board, oppCombos) {
    const used = new Uint8Array(52);
    used[hero[0]] = 1; used[hero[1]] = 1;
    for (const b of board) used[b] = 1;
    const hs = evalWith(hero, board);
    let w = 0, t = 0, l = 0, tot = 0;
    for (const cb of oppCombos) {
      if (used[cb[0]] || used[cb[1]]) continue;
      const s = evalWith([cb[0], cb[1]], board);
      const wt = cb[2];
      tot += wt;
      if (hs > s) w += wt; else if (hs === s) t += wt; else l += wt;
    }
    if (!tot) return { equity: 0.5, win: 0, tie: 0, lose: 0, iters: 0, exact: true };
    return { equity: (w + t / 2) / tot, win: w / tot, tie: t / tot, lose: l / tot, iters: tot, exact: true };
  }

  G.equity = {
    rangeToCombos, fullRangeCombos, combosWeight, features, percentileOnBoard,
    narrowRange, equity, equityExact, evalWith, boardScores,
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
