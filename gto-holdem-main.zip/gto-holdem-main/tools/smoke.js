/* 全参数矩阵冒烟测试: 只查异常与非法输出 */
globalThis.GTO = {};
['evaluator','ranges','ranking','equity','advisor'].forEach(m=>require('../src/'+m+'.js'));
const { cards: C, ranges: RG, advisor: AD } = globalThis.GTO;
const h=s=>s.trim().split(/\s+/).map(C.cardFromStr);
const errs=[]; let n=0;
const boards=['','Qs 7s 2h','Ks Ks 2h','Qs 7s 2h 9d','Qs 7s 2h 9d 3c','2c 2d 2h 2s 5c'];
const scen=['unopened','vs_raise','vs_limp','vs_3bet','vs_4bet'];
const roles=['opener','caller','3bettor','bbdefend','unknown'];
const facings=['none','check','bet','raise'];
const hands=['As Ks','7h 2d','9s 9h','Ts 9s'];
for(const ts of [2,3,4,5,6,7,8,9]){
 for(const hp of RG.positionsFor(ts)){
  const others=RG.positionsFor(ts).filter(p=>p!==hp);
  for(const b of boards){
   const board=b?h(b):[];
   for(const hand of hands){
    const hero=h(hand);
    if(board.some(c=>hero.includes(c))) continue;
    const scs=board.length?['unopened']:scen;
    const ros=board.length?roles:['opener'];
    const fas=board.length?facings:['none'];
    for(const sc of scs) for(const ro of ros) for(const fa of fas){
     n++;
     try{
      const r=AD.analyze({tableSize:ts,heroPos:hp,hero,board,
       street:board.length===0?'preflop':board.length===3?'flop':board.length===4?'turn':'river',
       effStack:100,potBB:6,toCallBB:(fa==='bet'||fa==='raise')?3:0,scenario:sc,
       raiserPos:others[0],openSizeBB:2.5,callers:0,limpers:1,villains:1,villainRole:ro,
       villainPos:others[0],history:{flop:'call',turn:'call',river:'none'},facing:fa,
       inPosition:true,heroInvested:0});
      const sum=r.actions.reduce((a,x)=>a+x.freq,0);
      const tag=`${ts}人/${hp}/${b||'翻前'}/${hand}/${sc}/${ro}/${fa}`;
      if(Math.abs(sum-1)>0.01) errs.push('频率和≠1 '+sum.toFixed(3)+' @ '+tag);
      if(!(r.equity>=0&&r.equity<=1)) errs.push('胜率越界 '+r.equity+' @ '+tag);
      if(r.actions.some(a=>!isFinite(a.ev))) errs.push('EV 非数 @ '+tag);
      if(r.actions.some(a=>!isFinite(a.freq)||a.freq<0)) errs.push('频率非法 @ '+tag);
      if(!r.reasons.length) errs.push('无说明 @ '+tag);
     }catch(e){errs.push('异常 '+e.message+' @ '+`${ts}人/${hp}/${b||'翻前'}/${hand}/${sc}/${ro}/${fa}`);}
    }
 }}}}
console.log(`共 ${n} 组组合`);
if(errs.length){console.log(`❌ ${errs.length} 个问题:`);errs.slice(0,12).forEach(e=>console.log('  '+e));process.exit(1);}
else console.log('✅ 无异常, 频率与 EV 均合法');
